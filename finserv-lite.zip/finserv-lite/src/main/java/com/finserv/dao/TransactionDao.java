package com.finserv.dao;

import com.finserv.model.Transaction;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Money movement. Every change goes through a stored procedure, which opens its own
 * transaction, locks the account rows and rolls back on any error.
 */
public class TransactionDao extends BaseDao {

    public void deposit(String accountNo, BigDecimal amount, String description) {
        call("{CALL sp_deposit(?, ?, ?)}", accountNo, amount, description);
    }

    public void withdraw(String accountNo, BigDecimal amount, String description) {
        call("{CALL sp_withdraw(?, ?, ?)}", accountNo, amount, description);
    }

    public void transfer(String fromAccountNo, String toAccountNo, BigDecimal amount, String description) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_transfer(?, ?, ?, ?)}")) {
            cs.setString(1, fromAccountNo);
            cs.setString(2, toAccountNo);
            cs.setBigDecimal(3, amount);
            cs.setString(4, description);
            cs.execute();
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** Newest first; uses the descending index on (account_id, txn_time). */
    public List<Transaction> recent(String accountNo, int limit) {
        String sql = "SELECT t.txn_id, t.txn_time, t.txn_type, t.amount, t.balance_after, t.description "
                + "FROM transactions t JOIN accounts a ON a.account_id = t.account_id "
                + "WHERE a.account_no = ? ORDER BY t.txn_time DESC, t.txn_id DESC LIMIT ?";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountNo);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                List<Transaction> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(new Transaction(rs.getLong(1), rs.getTimestamp(2).toLocalDateTime(), rs.getString(3),
                            rs.getBigDecimal(4), rs.getBigDecimal(5), rs.getString(6)));
                }
                return list;
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    private void call(String sql, String accountNo, BigDecimal amount, String description) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall(sql)) {
            cs.setString(1, accountNo);
            cs.setBigDecimal(2, amount);
            cs.setString(3, description);
            cs.execute();
        } catch (SQLException e) {
            throw wrap(e);
        }
    }
}
