package com.finserv.dao;

import com.finserv.model.Branch;
import com.finserv.util.ResultSetUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Reads branches and the v_branch_summary view. */
public class BranchDao extends BaseDao {

    public List<Branch> findAll() {
        String sql = "SELECT branch_id, branch_name, ifsc_code, city, is_active FROM branches ORDER BY branch_id";
        try (Connection c = connection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<Branch> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new Branch(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getBoolean(5)));
            }
            return list;
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** One row per branch: account count, total, average and largest balance (a database view). */
    public List<Map<String, Object>> summary() {
        String sql = "SELECT * FROM v_branch_summary ORDER BY total_balance DESC";
        try (Connection c = connection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return ResultSetUtil.toRows(rs);
        } catch (SQLException e) {
            throw wrap(e);
        }
    }
}
