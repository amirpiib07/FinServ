package com.finserv.dao;

import com.finserv.util.ResultSetUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

/** Read-only reports built on views, window functions and the audit table. */
public class ReportDao extends BaseDao {

    /** v_customer_portfolio ranks customers with RANK() OVER (...) and a stored function. */
    public List<Map<String, Object>> topCustomers(int limit) {
        return query("SELECT customer_id, full_name, total_balance, segment, balance_rank "
                + "FROM v_customer_portfolio ORDER BY balance_rank, customer_id LIMIT ?", limit);
    }

    public List<Map<String, Object>> monthlySummary() {
        String sql = "SELECT * FROM v_monthly_txn_summary ORDER BY txn_year, txn_month, txn_type";
        try (Connection c = connection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return ResultSetUtil.toRows(rs);
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** Latest audit rows written by triggers; JSON columns come back as text. */
    public List<Map<String, Object>> auditTrail(int limit) {
        return query("SELECT audit_id, table_name, action, record_id, old_data, new_data, changed_at "
                + "FROM audit_log ORDER BY audit_id DESC LIMIT ?", limit);
    }

    private List<Map<String, Object>> query(String sql, int limit) {
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                return ResultSetUtil.toRows(rs);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }
}
