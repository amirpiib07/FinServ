package com.finserv.dao;

import com.finserv.config.DatabaseConfig;
import com.finserv.exception.BankException;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Parent of every DAO: opens connections and converts SQLException into BankException.
 * For errors raised by SIGNAL inside a stored routine, SQLException.getMessage() is the
 * text written in the SQL script (for example "Insufficient balance"), so it is shown as is.
 */
public abstract class BaseDao {

    protected Connection connection() throws SQLException {
        return DatabaseConfig.getInstance().getConnection();
    }

    protected BankException wrap(SQLException e) {
        return new BankException(e.getMessage(), e);
    }
}
