package com.finserv.dao;

import com.finserv.util.ResultSetUtil;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/** Loan procedures, the v_loan_status view and a recursive-CTE repayment schedule. */
public class LoanDao extends BaseDao {

    private static final String SCHEDULE_SQL = """
            WITH RECURSIVE schedule (month_no, opening_balance, interest, principal_paid, closing_balance, emi, rate, months) AS (
                SELECT 1, CAST(l.principal AS DECIMAL(14,2)),
                       ROUND(l.principal * l.annual_rate / 1200, 2),
                       l.emi - ROUND(l.principal * l.annual_rate / 1200, 2),
                       CAST(l.principal - (l.emi - ROUND(l.principal * l.annual_rate / 1200, 2)) AS DECIMAL(14,2)),
                       l.emi, l.annual_rate, l.months
                FROM loans l WHERE l.loan_id = ?
                UNION ALL
                SELECT month_no + 1, closing_balance, ROUND(closing_balance * rate / 1200, 2),
                       emi - ROUND(closing_balance * rate / 1200, 2),
                       CAST(closing_balance - (emi - ROUND(closing_balance * rate / 1200, 2)) AS DECIMAL(14,2)),
                       emi, rate, months
                FROM schedule WHERE month_no < months
            )
            SELECT month_no, opening_balance, interest, principal_paid, closing_balance FROM schedule
            """;

    /** CALL sp_apply_for_loan(..., OUT loan_id). The EMI is calculated by a trigger and a function. */
    public int apply(int customerId, String accountNo, BigDecimal principal, BigDecimal annualRate, int months) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_apply_for_loan(?, ?, ?, ?, ?, ?)}")) {
            cs.setInt(1, customerId);
            cs.setString(2, accountNo);
            cs.setBigDecimal(3, principal);
            cs.setBigDecimal(4, annualRate);
            cs.setInt(5, months);
            cs.registerOutParameter(6, Types.INTEGER);
            cs.execute();
            return cs.getInt(6);
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public void approve(int loanId) {
        callWithLoanId("{CALL sp_approve_loan(?)}", loanId);
    }

    public void payEmi(int loanId) {
        callWithLoanId("{CALL sp_pay_emi(?)}", loanId);
    }

    public List<Map<String, Object>> findByCustomer(int customerId) {
        String sql = "SELECT * FROM v_loan_status WHERE customer_id = ? ORDER BY loan_id";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                return ResultSetUtil.toRows(rs);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public List<Map<String, Object>> schedule(int loanId) {
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(SCHEDULE_SQL)) {
            ps.setInt(1, loanId);
            try (ResultSet rs = ps.executeQuery()) {
                return ResultSetUtil.toRows(rs);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    private void callWithLoanId(String sql, int loanId) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall(sql)) {
            cs.setInt(1, loanId);
            cs.execute();
        } catch (SQLException e) {
            throw wrap(e);
        }
    }
}
