package com.finserv.dao;

import com.finserv.model.Customer;
import com.finserv.util.ResultSetUtil;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** All SQL for the customers table. Triggers validate age and normalise the email. */
public class CustomerDao extends BaseDao {

    private static final String COLUMNS =
            "customer_id, full_name, email, phone, date_of_birth, kyc_status";

    public List<Customer> findAll() {
        String sql = "SELECT " + COLUMNS + " FROM customers ORDER BY customer_id";
        try (Connection c = connection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<Customer> list = new ArrayList<>();
            while (rs.next()) {
                list.add(map(rs));
            }
            return list;
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public Optional<Customer> findById(int id) {
        String sql = "SELECT " + COLUMNS + " FROM customers WHERE customer_id = ?";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** Inserts a customer; the address JSON is built inside MySQL with JSON_OBJECT. Returns the new id. */
    public int insert(String firstName, String lastName, String email, String phone,
                      LocalDate dateOfBirth, String city) {
        String sql = "INSERT INTO customers (first_name, last_name, email, phone, date_of_birth, address) "
                + "VALUES (?, ?, ?, ?, ?, JSON_OBJECT('city', ?))";
        try (Connection c = connection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, email);
            ps.setString(4, phone);
            ps.setDate(5, Date.valueOf(dateOfBirth));
            ps.setString(6, city);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public boolean updateKycStatus(int id, String status) {
        String sql = "UPDATE customers SET kyc_status = ? WHERE customer_id = ?";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** Calls the dynamic-SQL procedure sp_search_customers; either filter may be empty. */
    public List<Map<String, Object>> search(String name, String kycStatus) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_search_customers(?, ?)}")) {
            cs.setString(1, name);
            cs.setString(2, kycStatus);
            try (ResultSet rs = cs.executeQuery()) {
                return ResultSetUtil.toRows(rs);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    private Customer map(ResultSet rs) throws SQLException {
        return new Customer(rs.getInt("customer_id"), rs.getString("full_name"), rs.getString("email"),
                rs.getString("phone"), rs.getDate("date_of_birth").toLocalDate(), rs.getString("kyc_status"));
    }
}
