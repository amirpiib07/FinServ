package com.finserv.dao;

import com.finserv.model.Account;
import com.finserv.util.ResultSetUtil;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Account queries and the account-related stored procedures. */
public class AccountDao extends BaseDao {

    private static final String SELECT_ACCOUNT =
            "SELECT a.account_id, a.account_no, a.customer_id, t.type_name, b.branch_name, a.balance, a.status "
            + "FROM accounts a JOIN account_types t ON t.type_id = a.type_id "
            + "JOIN branches b ON b.branch_id = a.branch_id ";

    /** CALL sp_open_account(customer, branch, type, deposit, OUT account_no). Returns the new number. */
    public String openAccount(int customerId, int branchId, int typeId, BigDecimal initialDeposit) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_open_account(?, ?, ?, ?, ?)}")) {
            cs.setInt(1, customerId);
            cs.setInt(2, branchId);
            cs.setInt(3, typeId);
            cs.setBigDecimal(4, initialDeposit);
            cs.registerOutParameter(5, Types.CHAR);
            cs.execute();
            return cs.getString(5);
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public List<Account> findByCustomer(int customerId) {
        String sql = SELECT_ACCOUNT + "WHERE a.customer_id = ? ORDER BY a.account_id";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Account> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(map(rs));
                }
                return list;
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public Optional<Account> findByAccountNo(String accountNo) {
        String sql = SELECT_ACCOUNT + "WHERE a.account_no = ?";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountNo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    public void close(String accountNo) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_close_account(?)}")) {
            cs.setString(1, accountNo);
            cs.execute();
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** CALL sp_account_statement: ledger lines with a running total computed by a window function. */
    public List<Map<String, Object>> statement(String accountNo, LocalDate from, LocalDate to) {
        try (Connection c = connection(); CallableStatement cs = c.prepareCall("{CALL sp_account_statement(?, ?, ?)}")) {
            cs.setString(1, accountNo);
            setDate(cs, 2, from);
            setDate(cs, 3, to);
            try (ResultSet rs = cs.executeQuery()) {
                return ResultSetUtil.toRows(rs);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    /** Uses the stored function fn_customer_total_balance inside a normal SELECT. */
    public BigDecimal totalBalance(int customerId) {
        String sql = "SELECT fn_customer_total_balance(?)";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getBigDecimal(1);
            }
        } catch (SQLException e) {
            throw wrap(e);
        }
    }

    private void setDate(CallableStatement cs, int index, LocalDate value) throws SQLException {
        if (value == null) {
            cs.setNull(index, Types.DATE);
        } else {
            cs.setDate(index, Date.valueOf(value));
        }
    }

    private Account map(ResultSet rs) throws SQLException {
        return new Account(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4),
                rs.getString(5), rs.getBigDecimal(6), rs.getString(7));
    }
}
