package com.finserv.config;

import com.finserv.exception.BankException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Singleton that knows how to open connections to MySQL.
 * Settings come from db.properties on the classpath; the environment variables
 * FINSERV_DB_URL, FINSERV_DB_USER and FINSERV_DB_PASSWORD override them.
 */
public final class DatabaseConfig {

    private static DatabaseConfig instance;

    private final String url;
    private final String user;
    private final String password;

    private DatabaseConfig() {
        Properties props = new Properties();
        try (InputStream in = DatabaseConfig.class.getResourceAsStream("/db.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException e) {
            throw new BankException("Cannot read db.properties", e);
        }
        this.url = env("FINSERV_DB_URL", props.getProperty("db.url",
                "jdbc:mysql://localhost:3306/finserv_lite?connectionTimeZone=UTC"));
        this.user = env("FINSERV_DB_USER", props.getProperty("db.user", "root"));
        this.password = env("FINSERV_DB_PASSWORD", props.getProperty("db.password", ""));
    }

    public static synchronized DatabaseConfig getInstance() {
        if (instance == null) {
            instance = new DatabaseConfig();
        }
        return instance;
    }

    /** Opens a new connection; callers close it with try-with-resources. */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    private static String env(String name, String fallback) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? fallback : value;
    }
}
