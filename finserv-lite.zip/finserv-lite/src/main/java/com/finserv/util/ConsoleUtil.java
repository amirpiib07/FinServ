package com.finserv.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Console input and output helpers shared by all menus. */
public final class ConsoleUtil {

    private static final Scanner SCANNER = new Scanner(System.in);

    private ConsoleUtil() { }

    public static String readLine(String prompt) {
        System.out.print(prompt + ": ");
        return SCANNER.hasNextLine() ? SCANNER.nextLine().trim() : "";
    }

    public static int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readLine(prompt));
            } catch (NumberFormatException e) {
                error("Please enter a whole number.");
            }
        }
    }

    public static BigDecimal readDecimal(String prompt) {
        while (true) {
            try {
                return new BigDecimal(readLine(prompt));
            } catch (NumberFormatException e) {
                error("Please enter a number such as 2500.50");
            }
        }
    }

    /** Reads a date as yyyy-mm-dd; an empty answer returns null. */
    public static LocalDate readDate(String prompt) {
        while (true) {
            String text = readLine(prompt + " (yyyy-mm-dd, blank = none)");
            if (text.isEmpty()) {
                return null;
            }
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException e) {
                error("Use the format yyyy-mm-dd.");
            }
        }
    }

    public static void title(String text) {
        System.out.println();
        System.out.println("=== " + text + " ===");
    }

    public static void info(String text) {
        System.out.println(text);
    }

    public static void error(String text) {
        System.out.println("ERROR: " + text);
    }

    /** Prints rows as an aligned text table. */
    public static void printRows(List<Map<String, Object>> rows) {
        if (rows.isEmpty()) {
            info("(no rows)");
            return;
        }
        List<String> columns = List.copyOf(rows.get(0).keySet());
        int[] width = new int[columns.size()];
        for (int i = 0; i < width.length; i++) {
            width[i] = columns.get(i).length();
            for (Map<String, Object> row : rows) {
                width[i] = Math.max(width[i], String.valueOf(row.get(columns.get(i))).length());
            }
        }
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < width.length; i++) {
            System.out.printf("%-" + (width[i] + 2) + "s", columns.get(i));
            line.append("-".repeat(width[i])).append("  ");
        }
        System.out.println();
        System.out.println(line);
        for (Map<String, Object> row : rows) {
            for (int i = 0; i < width.length; i++) {
                System.out.printf("%-" + (width[i] + 2) + "s", row.get(columns.get(i)));
            }
            System.out.println();
        }
    }
}
