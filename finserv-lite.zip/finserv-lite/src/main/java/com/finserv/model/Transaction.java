package com.finserv.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** One ledger line. */
public record Transaction(long id, LocalDateTime time, String type, BigDecimal amount,
                          BigDecimal balanceAfter, String description) { }
