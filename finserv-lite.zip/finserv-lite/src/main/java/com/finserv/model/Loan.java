package com.finserv.model;

import java.math.BigDecimal;

/** One row of the loans table. */
public record Loan(int id, int customerId, BigDecimal principal, BigDecimal annualRate,
                   int months, BigDecimal emi, String status) { }
