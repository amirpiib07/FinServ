package com.finserv.model;

/** One row of the branches table. */
public record Branch(int id, String name, String ifscCode, String city, boolean active) { }
