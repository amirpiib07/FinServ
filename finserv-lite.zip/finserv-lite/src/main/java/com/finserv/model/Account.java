package com.finserv.model;

import java.math.BigDecimal;

/** An account joined with its type and branch names. */
public record Account(int id, String accountNo, int customerId, String typeName,
                      String branchName, BigDecimal balance, String status) { }
