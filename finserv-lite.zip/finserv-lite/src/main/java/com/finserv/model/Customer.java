package com.finserv.model;

import java.time.LocalDate;

/** One row of the customers table. */
public record Customer(int id, String fullName, String email, String phone,
                       LocalDate dateOfBirth, String kycStatus) { }
