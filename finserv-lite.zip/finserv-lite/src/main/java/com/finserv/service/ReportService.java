package com.finserv.service;

import com.finserv.dao.BranchDao;
import com.finserv.dao.ReportDao;
import com.finserv.model.Branch;

import java.util.List;
import java.util.Map;

/** Reports for managers and auditors. */
public class ReportService {

    private final ReportDao reportDao;
    private final BranchDao branchDao;

    public ReportService(ReportDao reportDao, BranchDao branchDao) {
        this.reportDao = reportDao;
        this.branchDao = branchDao;
    }

    public List<Branch> branches() {
        return branchDao.findAll();
    }

    public List<Map<String, Object>> branchSummary() {
        return branchDao.summary();
    }

    public List<Map<String, Object>> topCustomers(int limit) {
        return reportDao.topCustomers(limit);
    }

    public List<Map<String, Object>> monthlySummary() {
        return reportDao.monthlySummary();
    }

    public List<Map<String, Object>> auditTrail(int limit) {
        return reportDao.auditTrail(limit);
    }
}
