package com.finserv.service;

import com.finserv.dao.TransactionDao;
import com.finserv.exception.BankException;
import com.finserv.model.Transaction;

import java.math.BigDecimal;
import java.util.List;

/** Deposits, withdrawals and transfers. The stored procedures enforce the money rules. */
public class TransactionService {

    private final TransactionDao transactionDao;

    public TransactionService(TransactionDao transactionDao) {
        this.transactionDao = transactionDao;
    }

    public void deposit(String accountNo, BigDecimal amount, String description) {
        requirePositive(amount);
        transactionDao.deposit(accountNo, amount, description);
    }

    public void withdraw(String accountNo, BigDecimal amount, String description) {
        requirePositive(amount);
        transactionDao.withdraw(accountNo, amount, description);
    }

    public void transfer(String fromAccountNo, String toAccountNo, BigDecimal amount, String description) {
        requirePositive(amount);
        transactionDao.transfer(fromAccountNo, toAccountNo, amount, description);
    }

    public List<Transaction> recent(String accountNo, int limit) {
        return transactionDao.recent(accountNo, Math.max(1, Math.min(limit, 100)));
    }

    private void requirePositive(BigDecimal amount) {
        if (amount.signum() <= 0) {
            throw new BankException("Amount must be greater than zero.");
        }
    }
}
