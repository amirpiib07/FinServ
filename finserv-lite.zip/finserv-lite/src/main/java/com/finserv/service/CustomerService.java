package com.finserv.service;

import com.finserv.dao.CustomerDao;
import com.finserv.exception.BankException;
import com.finserv.model.Customer;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Customer rules that are easier to check before talking to the database. */
public class CustomerService {

    private static final Set<String> KYC_VALUES = Set.of("PENDING", "VERIFIED", "REJECTED");

    private final CustomerDao customerDao;

    public CustomerService(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    public int register(String firstName, String lastName, String email, String phone,
                        LocalDate dateOfBirth, String city) {
        if (firstName.isBlank() || lastName.isBlank()) {
            throw new BankException("First and last name are required.");
        }
        if (!email.contains("@")) {
            throw new BankException("Email address is not valid.");
        }
        return customerDao.insert(firstName, lastName, email, phone, dateOfBirth, city);
    }

    public List<Customer> listAll() {
        return customerDao.findAll();
    }

    public Customer get(int id) {
        return customerDao.findById(id).orElseThrow(() -> new BankException("Customer " + id + " not found."));
    }

    public void changeKyc(int id, String status) {
        String value = status.toUpperCase();
        if (!KYC_VALUES.contains(value)) {
            throw new BankException("KYC status must be one of " + KYC_VALUES);
        }
        if (!customerDao.updateKycStatus(id, value)) {
            throw new BankException("Customer " + id + " not found.");
        }
    }

    public List<Map<String, Object>> search(String name, String kycStatus) {
        return customerDao.search(name, kycStatus);
    }
}
