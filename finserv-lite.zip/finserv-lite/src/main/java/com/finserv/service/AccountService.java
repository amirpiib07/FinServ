package com.finserv.service;

import com.finserv.dao.AccountDao;
import com.finserv.exception.BankException;
import com.finserv.model.Account;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Opening, viewing and closing accounts. */
public class AccountService {

    private final AccountDao accountDao;

    public AccountService(AccountDao accountDao) {
        this.accountDao = accountDao;
    }

    public String open(int customerId, int branchId, int typeId, BigDecimal initialDeposit) {
        if (initialDeposit.signum() < 0) {
            throw new BankException("Opening deposit cannot be negative.");
        }
        return accountDao.openAccount(customerId, branchId, typeId, initialDeposit);
    }

    public List<Account> accountsOf(int customerId) {
        return accountDao.findByCustomer(customerId);
    }

    public Account get(String accountNo) {
        return accountDao.findByAccountNo(accountNo).orElseThrow(() -> new BankException("Account not found."));
    }

    public void close(String accountNo) {
        accountDao.close(accountNo);
    }

    public List<Map<String, Object>> statement(String accountNo, LocalDate from, LocalDate to) {
        if (from != null && to != null && from.isAfter(to)) {
            throw new BankException("The start date is after the end date.");
        }
        return accountDao.statement(accountNo, from, to);
    }

    public BigDecimal totalBalance(int customerId) {
        return accountDao.totalBalance(customerId);
    }
}
