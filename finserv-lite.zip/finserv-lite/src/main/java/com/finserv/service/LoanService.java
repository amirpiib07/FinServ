package com.finserv.service;

import com.finserv.dao.LoanDao;
import com.finserv.exception.BankException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/** Loan life cycle: apply, approve, pay EMIs, view schedule. */
public class LoanService {

    private final LoanDao loanDao;

    public LoanService(LoanDao loanDao) {
        this.loanDao = loanDao;
    }

    public int apply(int customerId, String accountNo, BigDecimal principal, BigDecimal annualRate, int months) {
        if (principal.signum() <= 0 || months < 1 || months > 360) {
            throw new BankException("Principal must be positive and months between 1 and 360.");
        }
        return loanDao.apply(customerId, accountNo, principal, annualRate, months);
    }

    public void approve(int loanId) {
        loanDao.approve(loanId);
    }

    public void payEmi(int loanId) {
        loanDao.payEmi(loanId);
    }

    public List<Map<String, Object>> loansOf(int customerId) {
        return loanDao.findByCustomer(customerId);
    }

    public List<Map<String, Object>> schedule(int loanId) {
        List<Map<String, Object>> rows = loanDao.schedule(loanId);
        if (rows.isEmpty()) {
            throw new BankException("Loan " + loanId + " not found.");
        }
        return rows;
    }
}
