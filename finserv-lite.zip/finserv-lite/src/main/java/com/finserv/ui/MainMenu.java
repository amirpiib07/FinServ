package com.finserv.ui;

import com.finserv.util.ConsoleUtil;

/** Top-level menu: sends the user to one of the sub-menus. */
public class MainMenu {

    private final CustomerMenu customerMenu;
    private final AccountMenu accountMenu;
    private final TransactionMenu transactionMenu;
    private final LoanMenu loanMenu;
    private final ReportMenu reportMenu;

    public MainMenu(CustomerMenu customerMenu, AccountMenu accountMenu, TransactionMenu transactionMenu,
                    LoanMenu loanMenu, ReportMenu reportMenu) {
        this.customerMenu = customerMenu;
        this.accountMenu = accountMenu;
        this.transactionMenu = transactionMenu;
        this.loanMenu = loanMenu;
        this.reportMenu = reportMenu;
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            ConsoleUtil.title("FinServ Lite - Main menu");
            ConsoleUtil.info("1) Customers   2) Accounts   3) Transactions   4) Loans   5) Reports   0) Exit");
            switch (ConsoleUtil.readInt("Choose")) {
                case 1 -> customerMenu.run();
                case 2 -> accountMenu.run();
                case 3 -> transactionMenu.run();
                case 4 -> loanMenu.run();
                case 5 -> reportMenu.run();
                case 0 -> exit = true;
                default -> ConsoleUtil.error("Unknown option.");
            }
        }
        ConsoleUtil.info("Goodbye.");
    }
}
