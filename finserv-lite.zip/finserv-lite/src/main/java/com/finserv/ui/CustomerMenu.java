package com.finserv.ui;

import com.finserv.exception.BankException;
import com.finserv.model.Customer;
import com.finserv.service.CustomerService;
import com.finserv.util.ConsoleUtil;

/** Menu for customer management. */
public class CustomerMenu {

    private final CustomerService customerService;

    public CustomerMenu(CustomerService customerService) {
        this.customerService = customerService;
    }

    public void run() {
        boolean back = false;
        while (!back) {
            ConsoleUtil.title("Customers");
            ConsoleUtil.info("1) List customers   2) Register customer   3) Change KYC status   4) Search   0) Back");
            try {
                switch (ConsoleUtil.readInt("Choose")) {
                    case 1 -> customerService.listAll().forEach(this::print);
                    case 2 -> register();
                    case 3 -> {
                        int id = ConsoleUtil.readInt("Customer id");
                        customerService.changeKyc(id, ConsoleUtil.readLine("New status (PENDING/VERIFIED/REJECTED)"));
                        ConsoleUtil.info("KYC status updated.");
                    }
                    case 4 -> ConsoleUtil.printRows(customerService.search(
                            ConsoleUtil.readLine("Name contains (blank = any)"),
                            ConsoleUtil.readLine("KYC status (blank = any)")));
                    case 0 -> back = true;
                    default -> ConsoleUtil.error("Unknown option.");
                }
            } catch (BankException e) {
                ConsoleUtil.error(e.getMessage());
            }
        }
    }

    private void register() {
        int id = customerService.register(
                ConsoleUtil.readLine("First name"), ConsoleUtil.readLine("Last name"),
                ConsoleUtil.readLine("Email"), ConsoleUtil.readLine("Phone (10 digits)"),
                ConsoleUtil.readDate("Date of birth"), ConsoleUtil.readLine("City"));
        ConsoleUtil.info("Customer created with id " + id + " (KYC is PENDING).");
    }

    private void print(Customer c) {
        ConsoleUtil.info(String.format("%3d  %-20s %-30s %-10s %s", c.id(), c.fullName(), c.email(), c.phone(), c.kycStatus()));
    }
}
