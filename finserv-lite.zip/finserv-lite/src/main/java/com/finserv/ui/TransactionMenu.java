package com.finserv.ui;

import com.finserv.exception.BankException;
import com.finserv.model.Transaction;
import com.finserv.service.TransactionService;
import com.finserv.util.ConsoleUtil;

/** Menu for deposits, withdrawals and transfers. */
public class TransactionMenu {

    private final TransactionService transactionService;

    public TransactionMenu(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    public void run() {
        boolean back = false;
        while (!back) {
            ConsoleUtil.title("Transactions");
            ConsoleUtil.info("1) Deposit   2) Withdraw   3) Transfer   4) Recent transactions   0) Back");
            try {
                switch (ConsoleUtil.readInt("Choose")) {
                    case 1 -> {
                        transactionService.deposit(ConsoleUtil.readLine("Account number"),
                                ConsoleUtil.readDecimal("Amount"), ConsoleUtil.readLine("Description"));
                        ConsoleUtil.info("Deposit done.");
                    }
                    case 2 -> {
                        transactionService.withdraw(ConsoleUtil.readLine("Account number"),
                                ConsoleUtil.readDecimal("Amount"), ConsoleUtil.readLine("Description"));
                        ConsoleUtil.info("Withdrawal done.");
                    }
                    case 3 -> {
                        transactionService.transfer(ConsoleUtil.readLine("From account"), ConsoleUtil.readLine("To account"),
                                ConsoleUtil.readDecimal("Amount"), ConsoleUtil.readLine("Description"));
                        ConsoleUtil.info("Transfer done.");
                    }
                    case 4 -> transactionService.recent(ConsoleUtil.readLine("Account number"),
                            ConsoleUtil.readInt("How many")).forEach(this::print);
                    case 0 -> back = true;
                    default -> ConsoleUtil.error("Unknown option.");
                }
            } catch (BankException e) {
                ConsoleUtil.error(e.getMessage());
            }
        }
    }

    private void print(Transaction t) {
        ConsoleUtil.info(String.format("%s  %-12s %12s  balance %12s  %s", t.time(), t.type(), t.amount(), t.balanceAfter(), t.description()));
    }
}
