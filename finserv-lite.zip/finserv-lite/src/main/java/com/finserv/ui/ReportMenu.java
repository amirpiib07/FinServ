package com.finserv.ui;

import com.finserv.exception.BankException;
import com.finserv.service.ReportService;
import com.finserv.util.ConsoleUtil;

/** Menu for reports. */
public class ReportMenu {

    private final ReportService reportService;

    public ReportMenu(ReportService reportService) {
        this.reportService = reportService;
    }

    public void run() {
        boolean back = false;
        while (!back) {
            ConsoleUtil.title("Reports");
            ConsoleUtil.info("1) Branches   2) Branch summary   3) Top customers   4) Monthly summary   5) Audit trail   0) Back");
            try {
                switch (ConsoleUtil.readInt("Choose")) {
                    case 1 -> reportService.branches().forEach(b -> ConsoleUtil.info(
                            b.id() + "  " + b.name() + "  " + b.ifscCode() + "  " + b.city() + (b.active() ? "" : "  (inactive)")));
                    case 2 -> ConsoleUtil.printRows(reportService.branchSummary());
                    case 3 -> ConsoleUtil.printRows(reportService.topCustomers(ConsoleUtil.readInt("How many")));
                    case 4 -> ConsoleUtil.printRows(reportService.monthlySummary());
                    case 5 -> ConsoleUtil.printRows(reportService.auditTrail(ConsoleUtil.readInt("How many rows")));
                    case 0 -> back = true;
                    default -> ConsoleUtil.error("Unknown option.");
                }
            } catch (BankException e) {
                ConsoleUtil.error(e.getMessage());
            }
        }
    }
}
