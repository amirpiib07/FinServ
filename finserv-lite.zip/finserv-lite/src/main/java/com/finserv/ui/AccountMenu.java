package com.finserv.ui;

import com.finserv.exception.BankException;
import com.finserv.model.Account;
import com.finserv.service.AccountService;
import com.finserv.util.ConsoleUtil;

/** Menu for accounts. */
public class AccountMenu {

    private final AccountService accountService;

    public AccountMenu(AccountService accountService) {
        this.accountService = accountService;
    }

    public void run() {
        boolean back = false;
        while (!back) {
            ConsoleUtil.title("Accounts");
            ConsoleUtil.info("1) Open account   2) Accounts of a customer   3) Statement   4) Close account   0) Back");
            try {
                switch (ConsoleUtil.readInt("Choose")) {
                    case 1 -> {
                        String no = accountService.open(ConsoleUtil.readInt("Customer id"),
                                ConsoleUtil.readInt("Branch id"),
                                ConsoleUtil.readInt("Type id (1 Savings, 2 Current, 3 Salary, 4 Student)"),
                                ConsoleUtil.readDecimal("Opening deposit"));
                        ConsoleUtil.info("Account opened. Number: " + no);
                    }
                    case 2 -> {
                        int id = ConsoleUtil.readInt("Customer id");
                        accountService.accountsOf(id).forEach(this::print);
                        ConsoleUtil.info("Total balance: " + accountService.totalBalance(id));
                    }
                    case 3 -> ConsoleUtil.printRows(accountService.statement(
                            ConsoleUtil.readLine("Account number"), ConsoleUtil.readDate("From"), ConsoleUtil.readDate("To")));
                    case 4 -> {
                        accountService.close(ConsoleUtil.readLine("Account number"));
                        ConsoleUtil.info("Account closed.");
                    }
                    case 0 -> back = true;
                    default -> ConsoleUtil.error("Unknown option.");
                }
            } catch (BankException e) {
                ConsoleUtil.error(e.getMessage());
            }
        }
    }

    private void print(Account a) {
        ConsoleUtil.info(String.format("%s  %-8s %-18s %12s  %s", a.accountNo(), a.typeName(), a.branchName(), a.balance(), a.status()));
    }
}
