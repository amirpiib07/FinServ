package com.finserv.ui;

import com.finserv.exception.BankException;
import com.finserv.service.LoanService;
import com.finserv.util.ConsoleUtil;

/** Menu for loans. */
public class LoanMenu {

    private final LoanService loanService;

    public LoanMenu(LoanService loanService) {
        this.loanService = loanService;
    }

    public void run() {
        boolean back = false;
        while (!back) {
            ConsoleUtil.title("Loans");
            ConsoleUtil.info("1) Apply   2) Approve   3) Pay EMI   4) Loans of a customer   5) Repayment schedule   0) Back");
            try {
                switch (ConsoleUtil.readInt("Choose")) {
                    case 1 -> {
                        int id = loanService.apply(ConsoleUtil.readInt("Customer id"), ConsoleUtil.readLine("Account number"),
                                ConsoleUtil.readDecimal("Principal"), ConsoleUtil.readDecimal("Annual rate %"),
                                ConsoleUtil.readInt("Months"));
                        ConsoleUtil.info("Loan " + id + " applied.");
                    }
                    case 2 -> {
                        loanService.approve(ConsoleUtil.readInt("Loan id"));
                        ConsoleUtil.info("Loan approved and money credited.");
                    }
                    case 3 -> {
                        loanService.payEmi(ConsoleUtil.readInt("Loan id"));
                        ConsoleUtil.info("EMI paid.");
                    }
                    case 4 -> ConsoleUtil.printRows(loanService.loansOf(ConsoleUtil.readInt("Customer id")));
                    case 5 -> ConsoleUtil.printRows(loanService.schedule(ConsoleUtil.readInt("Loan id")));
                    case 0 -> back = true;
                    default -> ConsoleUtil.error("Unknown option.");
                }
            } catch (BankException e) {
                ConsoleUtil.error(e.getMessage());
            }
        }
    }
}
