package com.finserv;

import com.finserv.dao.AccountDao;
import com.finserv.dao.BranchDao;
import com.finserv.dao.CustomerDao;
import com.finserv.dao.LoanDao;
import com.finserv.dao.ReportDao;
import com.finserv.dao.TransactionDao;
import com.finserv.service.AccountService;
import com.finserv.service.CustomerService;
import com.finserv.service.LoanService;
import com.finserv.service.ReportService;
import com.finserv.service.TransactionService;
import com.finserv.ui.AccountMenu;
import com.finserv.ui.CustomerMenu;
import com.finserv.ui.LoanMenu;
import com.finserv.ui.MainMenu;
import com.finserv.ui.ReportMenu;
import com.finserv.ui.TransactionMenu;

/** Wires the layers together (DAO to service to menu) and starts the console application. */
public final class Main {

    private Main() { }

    public static void main(String[] args) {
        CustomerService customers = new CustomerService(new CustomerDao());
        AccountService accounts = new AccountService(new AccountDao());
        TransactionService transactions = new TransactionService(new TransactionDao());
        LoanService loans = new LoanService(new LoanDao());
        ReportService reports = new ReportService(new ReportDao(), new BranchDao());

        new MainMenu(new CustomerMenu(customers), new AccountMenu(accounts), new TransactionMenu(transactions),
                new LoanMenu(loans), new ReportMenu(reports)).run();
    }
}
