#!/usr/bin/env python3
"""Builds the UML class diagram of FinServ Lite from the COMPILED classes (javap) so the
diagram always matches the code.  Needs: JDK (javap), Graphviz (dot).
Usage: python3 uml_from_classes.py <classes_dir> <output_basename>
"""
import html, re, subprocess, sys
from pathlib import Path

classes_dir, out_base = Path(sys.argv[1]), sys.argv[2]
PKG = "com.finserv"
ORDER = ["ui", "service", "dao", "model", "config", "exception", "util"]
TITLES = {"ui": "ui", "service": "service", "dao": "dao  (data access: all SQL lives here)", "model": "model",
          "config": "config", "exception": "exception", "util": "util", "": "app"}

def simple(t):
    t = re.sub(r"\b(?:[a-z_][a-z0-9_]*\.)+", "", t)
    return t.replace("java.lang.", "").replace(",", ", ")

class_files = sorted(p for p in classes_dir.rglob("*.class") if "$" not in p.name)
names = [str(p.relative_to(classes_dir))[:-6].replace("/", ".") for p in class_files]
info = {}
for fq in names:
    out = subprocess.run(["javap", "-p", "-cp", str(classes_dir), fq], capture_output=True, text=True, check=True).stdout
    lines = out.splitlines()
    head = lines[1]
    kind = "interface" if " interface " in head else "class"
    abstract = " abstract " in head and kind == "class"
    is_record = "extends java.lang.Record" in head
    parent = None
    m = re.search(r"extends ([\w.]+)", head)
    if m and not is_record:
        parent = m.group(1)
    short = fq.split(".")[-1]
    pkg = ".".join(fq.split(".")[:-1]).replace(PKG, "").lstrip(".")
    fields, methods = [], []
    for ln in lines[2:-1]:
        ln = ln.strip().rstrip(";")
        if not ln:
            continue
        vis = "+" if ln.startswith("public") else "-" if ln.startswith("private") else "#" if ln.startswith("protected") else "~"
        static = " static " in " " + ln + " "
        body = re.sub(r"\b(public|private|protected|static|final|abstract|synchronized)\b ?", "", ln).strip()
        if "(" in body:
            before, args = body.split("(", 1)
            args = args.rsplit(")", 1)[0]
            parts = before.rsplit(" ", 1)
            if len(parts) == 1:          # constructor
                if short in parts[0] and not args and vis == "+" and not is_record:
                    continue             # skip implicit no-arg public constructor
                methods.append((vis, f"{simple(parts[0]).split('.')[-1]}({simple(args)})", "", static))
                continue
            ret, name = parts
            if name.startswith("lambda$") or name.startswith("$"):
                continue
            if is_record and name in ("toString", "hashCode", "equals"):
                continue
            if is_record and not args and name in [f[1] for f in fields]:
                continue                 # record accessor = component
            methods.append((vis, f"{name}({simple(args)})", simple(ret), static))
        else:
            if " " not in body:          # static initializer block, nothing to draw
                continue
            ftype, fname = body.rsplit(" ", 1)
            fields.append((vis, fname, simple(ftype), static))
    info[short] = dict(fq=fq, pkg=pkg, kind=kind, abstract=abstract, record=is_record, parent=parent,
                       fields=fields, methods=methods)

def node(short):
    d = info[short]
    stereo = "&laquo;record&raquo;" if d["record"] else "&laquo;interface&raquo;" if d["kind"] == "interface" else "&laquo;abstract&raquo;" if d["abstract"] else ""
    if short == "DatabaseConfig": stereo = "&laquo;singleton&raquo;"
    if short in ("ConsoleUtil", "ResultSetUtil"): stereo = "&laquo;utility&raquo;"
    rows = []
    if stereo: rows.append(f'<TR><TD ALIGN="CENTER"><FONT POINT-SIZE="9">{stereo}</FONT></TD></TR>')
    nm = f"<I>{short}</I>" if d["abstract"] else short
    rows.append(f'<TR><TD ALIGN="CENTER" BGCOLOR="#EEF2F8"><B>{nm}</B></TD></TR>')
    def fmt(vis, name, typ, static, is_method):
        txt = html.escape(f"{vis}{name}" + (f": {typ}" if typ else ""))
        if static: txt = f"<U>{txt}</U>"
        return f'<FONT POINT-SIZE="9">{txt}</FONT>'
    f_txt = "<BR ALIGN=\"LEFT\"/>".join(fmt(v, n, t, s, False) for v, n, t, s in d["fields"]) or " "
    rows.append(f'<TR><TD ALIGN="LEFT" BALIGN="LEFT">{f_txt}<BR ALIGN="LEFT"/></TD></TR>')
    m_txt = "<BR ALIGN=\"LEFT\"/>".join(fmt(v, n, t, s, True) for v, n, t, s in d["methods"]) or " "
    rows.append(f'<TR><TD ALIGN="LEFT" BALIGN="LEFT">{m_txt}<BR ALIGN="LEFT"/></TD></TR>')
    return f'{short} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3">{"".join(rows)}</TABLE>>];'

g = ['digraph UML {', 'rankdir=LR; compound=true; nodesep=0.35; ranksep=1.3; splines=true; fontname="Helvetica";',
     'graph [bgcolor="white", pad=0.4, labelloc=t, fontsize=26, label=<<B>FinServ Lite - UML Class Diagram</B>>];',
     'node [shape=plain, fontname="Helvetica"]; edge [fontname="Helvetica", fontsize=10, arrowsize=0.9];']
for pkg in ORDER:
    members = sorted(s for s, d in info.items() if d["pkg"] == pkg)
    if not members: continue
    g.append(f'subgraph cluster_{pkg} {{ label=<<B>{html.escape(TITLES[pkg])}</B>>; labeljust=l; style="dashed"; color="#444444"; fontsize=15; margin=14;')
    g += [node(s) for s in members]
    g.append('}')
for s in sorted(s for s, d in info.items() if d["pkg"] == ""):
    g.append(node(s))
g.append('RuntimeException [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3"><TR><TD>&laquo;java.lang&raquo;<BR/><B>RuntimeException</B></TD></TR></TABLE>>];')

edges = set()
def edge(a, b, attrs): edges.add(f'{a} -> {b} [{attrs}];')
for s, d in info.items():
    if d["parent"]:
        p = d["parent"].split(".")[-1]
        if p in info or p == "RuntimeException":
            edge(s, p, 'arrowhead=empty, color="black"')
    for _, _, typ, _ in d["fields"]:
        for t in re.findall(r"[A-Z]\w*", typ):
            if t in info and t != s and info[t]["pkg"] != d["pkg"] or (t in info and t != s and d["pkg"] == "ui"):
                p1, p2 = d["pkg"], info[t]["pkg"]
                if p1 == "ui" and p2 in ("service", "ui"):
                    edge(s, t, 'label="calls" , arrowhead=vee, taillabel="1", headlabel="1", labeldistance=2' if p2 == "service" else 'label="opens", arrowhead=vee')
                elif p1 == "service" and p2 == "dao":
                    edge(s, t, 'label="uses", arrowhead=vee, headlabel="1", taillabel="1", labeldistance=2')
for s, d in info.items():
    if d["pkg"] == "dao":
        returned = set()
        for _, _, typ, _ in d["methods"]:
            for t in re.findall(r"[A-Z]\w*", typ):
                if t in info and info[t]["pkg"] == "model": returned.add(t)
        for t in returned:
            edge(s, t, 'label="returns", style=dashed, arrowhead=vee, headlabel="0..*", labeldistance=2')
edge("BaseDao", "DatabaseConfig", 'label="opens connections via", style=dashed, arrowhead=vee')
edge("BaseDao", "BankException", 'label="throws", style=dashed, arrowhead=vee')
edge("Main", "MainMenu", 'label="creates and starts", arrowhead=vee')
g += sorted(edges)
g.append('''Legend [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4">
<TR><TD ALIGN="LEFT"><B>Legend</B></TD></TR>
<TR><TD ALIGN="LEFT">solid line, hollow triangle = extends</TD></TR>
<TR><TD ALIGN="LEFT">solid line, open arrow = association</TD></TR>
<TR><TD ALIGN="LEFT">dashed line, open arrow = uses / returns / throws</TD></TR>
<TR><TD ALIGN="LEFT">+ public   - private   # protected   ~ package</TD></TR>
<TR><TD ALIGN="LEFT"><U>underline</U> = static   <I>italic</I> = abstract</TD></TR>
<TR><TD ALIGN="LEFT">0..* = many, 1 = one</TD></TR>
<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="9">Not drawn: menus use util.ConsoleUtil, DAOs use util.ResultSetUtil,<BR ALIGN="LEFT"/>every service and DAO throws exception.BankException,<BR ALIGN="LEFT"/>Main creates all DAOs, services and menus.<BR ALIGN="LEFT"/></FONT></TD></TR>
</TABLE>>];''')
g.append('}')
Path(out_base + ".dot").write_text("\n".join(g))
for fmt in ("pdf", "png"):
    extra = ["-Gdpi=130"] if fmt == "png" else []
    subprocess.run(["dot", f"-T{fmt}", *extra, out_base + ".dot", "-o", f"{out_base}.{fmt}"], check=True)
print("classes:", len(info), "edges:", len(edges))
