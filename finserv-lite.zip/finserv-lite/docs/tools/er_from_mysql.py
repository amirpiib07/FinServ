#!/usr/bin/env python3
"""Draws the ER diagram of the finserv_lite database from INFORMATION_SCHEMA.
Needs: mysql client, Graphviz (dot).  Usage: python3 er_from_mysql.py <output_basename> [mysql options]
"""
import html, subprocess, sys
from collections import defaultdict
from pathlib import Path

out_base, mysql_opts = sys.argv[1], sys.argv[2:]
DB = "finserv_lite"

def q(sql):
    r = subprocess.run(["mysql", *mysql_opts, "-N", "-B", "-e", sql], capture_output=True, text=True, check=True)
    return [line.split("\t") for line in r.stdout.splitlines()]

cols = defaultdict(list)
for t, c, typ, key, extra in q(f"SELECT c.TABLE_NAME, c.COLUMN_NAME, c.COLUMN_TYPE, c.COLUMN_KEY, c.EXTRA FROM information_schema.COLUMNS c "
                               f"JOIN information_schema.TABLES t ON t.TABLE_SCHEMA = c.TABLE_SCHEMA AND t.TABLE_NAME = c.TABLE_NAME "
                               f"WHERE c.TABLE_SCHEMA='{DB}' AND t.TABLE_TYPE = 'BASE TABLE' ORDER BY c.TABLE_NAME, c.ORDINAL_POSITION"):
    cols[t].append((c, typ, key, extra))
fks = q(f"SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE "
        f"WHERE TABLE_SCHEMA='{DB}' AND REFERENCED_TABLE_NAME IS NOT NULL")
fk_cols = {(t, c) for t, c, _, _ in fks}

g = ['digraph ER { rankdir=LR; nodesep=0.5; ranksep=1.4; pad=0.4; fontname="Helvetica"; bgcolor="white";',
     'labelloc=t; fontsize=26; label=<<B>FinServ Lite - ER Diagram (database finserv_lite)</B>>;',
     'node [shape=plain, fontname="Helvetica"]; edge [fontname="Helvetica", fontsize=10];']
for t, cl in cols.items():
    rows = [f'<TR><TD COLSPAN="3" BGCOLOR="#14284B"><FONT COLOR="white"><B>{t}</B></FONT></TD></TR>']
    for c, typ, key, extra in cl:
        tags = []
        if key == "PRI": tags.append("PK")
        if (t, c) in fk_cols: tags.append("FK")
        if key == "UNI": tags.append("UQ")
        if "STORED GENERATED" in extra.upper() or "VIRTUAL GENERATED" in extra.upper(): tags.append("GEN")
        name = f"<B>{html.escape(c)}</B>" if "PK" in tags else html.escape(c)
        tag_text = f'<FONT POINT-SIZE="10" COLOR="#B8860B"><B>{" ".join(tags)}</B></FONT>' if tags else " "
        rows.append(f'<TR><TD ALIGN="LEFT" PORT="{c}">{name}</TD>'
                    f'<TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="#555555">{html.escape(typ)}</FONT></TD>'
                    f'<TD ALIGN="LEFT">{tag_text}</TD></TR>')
    g.append(f'{t} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4">{"".join(rows)}</TABLE>>];')
for t, c, rt, rc in fks:
    g.append(f'{t}:{c} -> {rt}:{rc} [dir=both, arrowtail=crow, arrowhead=tee, label="{c}"];')
g.append('Legend [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4"><TR><TD ALIGN="LEFT"><B>Legend</B></TD></TR>'
         '<TR><TD ALIGN="LEFT">PK primary key   FK foreign key   UQ unique   GEN generated column</TD></TR>'
         '<TR><TD ALIGN="LEFT">crow foot = many, bar = one (all foreign keys are ON DELETE RESTRICT)</TD></TR></TABLE>>];')
g.append('}')
Path(out_base + ".dot").write_text("\n".join(g))
for fmt in ("pdf", "png"):
    extra = ["-Gdpi=130"] if fmt == "png" else []
    subprocess.run(["dot", f"-T{fmt}", *extra, out_base + ".dot", "-o", f"{out_base}.{fmt}"], check=True)
print("tables:", len(cols), "foreign keys:", len(fks))
