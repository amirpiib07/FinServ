-- =============================================================================
-- FinServ Lite - 05_procedures.sql
-- Topic    : Stored procedures - IN / OUT / INOUT parameters, variables, IF /
--            CASE / WHILE / REPEAT / LOOP, cursors, handlers, SIGNAL / RESIGNAL,
--            START TRANSACTION / COMMIT / ROLLBACK, SELECT ... FOR UPDATE,
--            dynamic SQL (PREPARE / EXECUTE), window functions in a result set.
-- Run order: 5 of 14
-- Design   : sp_post_entry is the ONLY place that changes a balance. It must be
--            called inside a transaction opened by the caller. All public
--            procedures below open and finish that transaction themselves.
-- =============================================================================
USE finserv_lite;
DELIMITER $$

-- ---------------------------------------------------------------------------
-- sp_post_entry: lock one account row, apply a credit or debit, write the ledger row.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_post_entry$$
CREATE PROCEDURE sp_post_entry(
    IN p_account_id INT UNSIGNED,
    IN p_type       VARCHAR(20),
    IN p_amount     DECIMAL(14,2),
    IN p_ref        CHAR(36),
    IN p_desc       VARCHAR(200))
BEGIN
    DECLARE v_balance   DECIMAL(14,2);
    DECLARE v_min       DECIMAL(12,2);
    DECLARE v_status    VARCHAR(10);
    DECLARE v_new       DECIMAL(14,2);
    DECLARE v_is_credit BOOLEAN DEFAULT (p_type IN ('DEPOSIT', 'TRANSFER_IN', 'INTEREST'));

    IF p_amount IS NULL OR p_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Amount must be greater than zero';
    END IF;

    -- FOR UPDATE locks the row until COMMIT/ROLLBACK, so two sessions cannot overdraw.
    SELECT a.balance, a.status, t.min_balance
      INTO v_balance, v_status, v_min
      FROM accounts a
      JOIN account_types t ON t.type_id = a.type_id
     WHERE a.account_id = p_account_id
       FOR UPDATE;

    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account not found';
    END IF;

    IF v_is_credit THEN
        IF v_status NOT IN ('ACTIVE', 'DORMANT') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account cannot receive money in its current status';
        END IF;
        SET v_new = v_balance + p_amount;
    ELSE
        IF v_status <> 'ACTIVE' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account is not active';
        END IF;
        SET v_new = v_balance - p_amount;
        IF v_new < v_min THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance (minimum balance rule)';
        END IF;
    END IF;

    UPDATE accounts
       SET balance = v_new,
           status  = IF(status = 'DORMANT', 'ACTIVE', status)   -- money in reactivates the account
     WHERE account_id = p_account_id;

    -- txn_time is given explicitly: a STORED generated column (txn_date) cannot be
    -- computed from a DEFAULT CURRENT_TIMESTAMP value, so the value must be supplied.
    INSERT INTO transactions (account_id, txn_type, amount, balance_after, transfer_ref, description, txn_time)
    VALUES (p_account_id, p_type, p_amount, v_new, p_ref, p_desc, NOW());
END$$

-- ---------------------------------------------------------------------------
-- sp_deposit / sp_withdraw
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_deposit$$
CREATE PROCEDURE sp_deposit(IN p_account_no CHAR(12), IN p_amount DECIMAL(14,2), IN p_desc VARCHAR(200))
BEGIN
    DECLARE v_id INT UNSIGNED;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;                       -- rethrow the original error to the caller
    END;

    SELECT account_id INTO v_id FROM accounts WHERE account_no = p_account_no;
    IF v_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account not found';
    END IF;

    START TRANSACTION;
    CALL sp_post_entry(v_id, 'DEPOSIT', p_amount, NULL, IFNULL(p_desc, 'Deposit'));
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_withdraw$$
CREATE PROCEDURE sp_withdraw(IN p_account_no CHAR(12), IN p_amount DECIMAL(14,2), IN p_desc VARCHAR(200))
BEGIN
    DECLARE v_id INT UNSIGNED;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SELECT account_id INTO v_id FROM accounts WHERE account_no = p_account_no;
    IF v_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account not found';
    END IF;

    START TRANSACTION;
    CALL sp_post_entry(v_id, 'WITHDRAWAL', p_amount, NULL, IFNULL(p_desc, 'Withdrawal'));
    COMMIT;
END$$

-- ---------------------------------------------------------------------------
-- sp_transfer: two ledger rows linked by one UUID. Rows are locked in id order
-- (lowest id first) so two opposite transfers can never deadlock.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_transfer$$
CREATE PROCEDURE sp_transfer(
    IN p_from_no CHAR(12), IN p_to_no CHAR(12), IN p_amount DECIMAL(14,2), IN p_desc VARCHAR(200))
BEGIN
    DECLARE v_from INT UNSIGNED;
    DECLARE v_to   INT UNSIGNED;
    DECLARE v_lock INT UNSIGNED;
    DECLARE v_ref  CHAR(36) DEFAULT UUID();
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    IF p_from_no = p_to_no THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot transfer to the same account';
    END IF;

    SELECT account_id INTO v_from FROM accounts WHERE account_no = p_from_no;
    SELECT account_id INTO v_to   FROM accounts WHERE account_no = p_to_no;
    IF v_from IS NULL OR v_to IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Source or destination account not found';
    END IF;

    START TRANSACTION;
    SELECT account_id INTO v_lock FROM accounts WHERE account_id = LEAST(v_from, v_to)    FOR UPDATE;
    SELECT account_id INTO v_lock FROM accounts WHERE account_id = GREATEST(v_from, v_to) FOR UPDATE;
    CALL sp_post_entry(v_from, 'TRANSFER_OUT', p_amount, v_ref, CONCAT('To ', fn_mask_account(p_to_no),   ': ', IFNULL(p_desc, 'Transfer')));
    CALL sp_post_entry(v_to,   'TRANSFER_IN',  p_amount, v_ref, CONCAT('From ', fn_mask_account(p_from_no), ': ', IFNULL(p_desc, 'Transfer')));
    COMMIT;
END$$

-- ---------------------------------------------------------------------------
-- sp_open_account: OUT parameter returns the new account number.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_open_account$$
CREATE PROCEDURE sp_open_account(
    IN  p_customer_id     INT UNSIGNED,
    IN  p_branch_id       INT UNSIGNED,
    IN  p_type_id         TINYINT UNSIGNED,
    IN  p_initial_deposit DECIMAL(14,2),
    OUT p_account_no      CHAR(12))
BEGIN
    DECLARE v_kyc    VARCHAR(10);
    DECLARE v_active BOOLEAN;
    DECLARE v_min    DECIMAL(12,2);
    DECLARE v_no     CHAR(12);
    DECLARE v_id     INT UNSIGNED;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SELECT kyc_status INTO v_kyc FROM customers WHERE customer_id = p_customer_id;
    IF v_kyc IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Customer not found';
    ELSEIF v_kyc <> 'VERIFIED' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'KYC is not verified';
    END IF;

    SELECT is_active INTO v_active FROM branches WHERE branch_id = p_branch_id;
    IF v_active IS NULL OR v_active = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Branch not found or inactive';
    END IF;

    SELECT min_balance INTO v_min FROM account_types WHERE type_id = p_type_id;
    IF v_min IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account type not found';
    ELSEIF IFNULL(p_initial_deposit, 0) < v_min THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Opening deposit is below the minimum balance';
    END IF;

    -- REPEAT ... UNTIL: keep generating until the number is unused.
    REPEAT
        SET v_no = fn_generate_account_no();
    UNTIL NOT EXISTS (SELECT 1 FROM accounts WHERE account_no = v_no)
    END REPEAT;

    START TRANSACTION;
    INSERT INTO accounts (account_no, customer_id, branch_id, type_id, balance)
    VALUES (v_no, p_customer_id, p_branch_id, p_type_id, 0);
    SET v_id = LAST_INSERT_ID();
    IF IFNULL(p_initial_deposit, 0) > 0 THEN
        CALL sp_post_entry(v_id, 'DEPOSIT', p_initial_deposit, NULL, 'Opening deposit');
    END IF;
    COMMIT;

    SET p_account_no = v_no;
END$$

-- ---------------------------------------------------------------------------
-- sp_close_account: only a zero-balance account can be closed.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_close_account$$
CREATE PROCEDURE sp_close_account(IN p_account_no CHAR(12))
BEGIN
    DECLARE v_balance DECIMAL(14,2);
    SELECT balance INTO v_balance FROM accounts WHERE account_no = p_account_no;
    IF v_balance IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account not found';
    ELSEIF v_balance <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Balance must be zero before closing';
    END IF;
    UPDATE accounts SET status = 'CLOSED' WHERE account_no = p_account_no;
END$$

-- ---------------------------------------------------------------------------
-- sp_apply_interest: CURSOR + CONTINUE HANDLER FOR NOT FOUND + LOOP / LEAVE.
-- Credits one month of interest to every active interest-bearing account.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_apply_interest$$
CREATE PROCEDURE sp_apply_interest(IN p_run_date DATE, OUT p_accounts_credited INT)
BEGIN
    DECLARE v_done     BOOLEAN DEFAULT FALSE;
    DECLARE v_account  INT UNSIGNED;
    DECLARE v_interest DECIMAL(14,2);
    DECLARE v_count    INT DEFAULT 0;

    DECLARE cur CURSOR FOR
        SELECT a.account_id, ROUND(a.balance * t.interest_rate / 1200, 2)
          FROM accounts a
          JOIN account_types t ON t.type_id = a.type_id
         WHERE a.status = 'ACTIVE' AND t.interest_rate > 0 AND a.balance > 0;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_account, v_interest;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        IF v_interest > 0 THEN
            CALL sp_post_entry(v_account, 'INTEREST', v_interest, NULL,
                               CONCAT('Interest for ', DATE_FORMAT(p_run_date, '%b %Y')));
            SET v_count = v_count + 1;
        END IF;
    END LOOP;
    CLOSE cur;
    COMMIT;

    SET p_accounts_credited = v_count;
END$$

-- ---------------------------------------------------------------------------
-- Loans: apply, approve (disburse), pay EMI
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_apply_for_loan$$
CREATE PROCEDURE sp_apply_for_loan(
    IN  p_customer_id INT UNSIGNED, IN p_account_no CHAR(12),
    IN  p_principal DECIMAL(12,2),  IN p_rate DECIMAL(5,2), IN p_months SMALLINT UNSIGNED,
    OUT p_loan_id INT UNSIGNED)
BEGIN
    DECLARE v_account INT UNSIGNED;
    DECLARE v_kyc     VARCHAR(10);

    SELECT kyc_status INTO v_kyc FROM customers WHERE customer_id = p_customer_id;
    IF v_kyc IS NULL OR v_kyc <> 'VERIFIED' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Customer not found or KYC not verified';
    END IF;

    SELECT account_id INTO v_account FROM accounts
     WHERE account_no = p_account_no AND customer_id = p_customer_id AND status = 'ACTIVE';
    IF v_account IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Active account of this customer not found';
    END IF;

    INSERT INTO loans (customer_id, account_id, principal, annual_rate, months)
    VALUES (p_customer_id, v_account, p_principal, p_rate, p_months);   -- emi is set by trigger
    SET p_loan_id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS sp_approve_loan$$
CREATE PROCEDURE sp_approve_loan(IN p_loan_id INT UNSIGNED)
BEGIN
    DECLARE v_status    VARCHAR(10);
    DECLARE v_account   INT UNSIGNED;
    DECLARE v_principal DECIMAL(12,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;
    SELECT status, account_id, principal INTO v_status, v_account, v_principal
      FROM loans WHERE loan_id = p_loan_id FOR UPDATE;
    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found';
    ELSEIF v_status <> 'APPLIED' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only an APPLIED loan can be approved';
    END IF;

    UPDATE loans SET status = 'ACTIVE' WHERE loan_id = p_loan_id;
    CALL sp_post_entry(v_account, 'DEPOSIT', v_principal, NULL, CONCAT('Loan disbursal #', p_loan_id));
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_pay_emi$$
CREATE PROCEDURE sp_pay_emi(IN p_loan_id INT UNSIGNED)
BEGIN
    DECLARE v_status      VARCHAR(10);
    DECLARE v_account     INT UNSIGNED;
    DECLARE v_principal   DECIMAL(12,2);
    DECLARE v_rate        DECIMAL(5,2);
    DECLARE v_emi         DECIMAL(12,2);
    DECLARE v_outstanding DECIMAL(12,2);
    DECLARE v_interest    DECIMAL(12,2);
    DECLARE v_payment     DECIMAL(12,2);
    DECLARE v_principal_part DECIMAL(12,2);
    DECLARE v_months      SMALLINT UNSIGNED;
    DECLARE v_paid_count  INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;
    SELECT status, account_id, principal, annual_rate, emi, months
      INTO v_status, v_account, v_principal, v_rate, v_emi, v_months
      FROM loans WHERE loan_id = p_loan_id FOR UPDATE;
    IF v_status IS NULL OR v_status <> 'ACTIVE' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found or not active';
    END IF;

    SELECT v_principal - IFNULL(SUM(principal_part), 0), COUNT(*) INTO v_outstanding, v_paid_count
      FROM loan_payments WHERE loan_id = p_loan_id;

    SET v_interest = ROUND(v_outstanding * v_rate / 1200, 2);
    IF v_paid_count + 1 >= v_months THEN
        SET v_payment = v_outstanding + v_interest;                    -- final EMI settles rounding differences
    ELSE
        SET v_payment = LEAST(v_emi, v_outstanding + v_interest);
    END IF;
    SET v_principal_part = v_payment - v_interest;

    CALL sp_post_entry(v_account, 'LOAN_EMI', v_payment, NULL, CONCAT('EMI for loan #', p_loan_id));
    INSERT INTO loan_payments (loan_id, amount, principal_part, interest_part)
    VALUES (p_loan_id, v_payment, v_principal_part, v_interest);

    IF v_outstanding - v_principal_part <= 0 THEN
        UPDATE loans SET status = 'CLOSED' WHERE loan_id = p_loan_id;
    END IF;
    COMMIT;
END$$

-- ---------------------------------------------------------------------------
-- sp_account_statement: returns a result set with a running total (window function).
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_account_statement$$
CREATE PROCEDURE sp_account_statement(IN p_account_no CHAR(12), IN p_from DATE, IN p_to DATE)
BEGIN
    SELECT t.txn_id,
           t.txn_time,
           t.txn_type,
           t.description,
           CASE WHEN t.txn_type IN ('DEPOSIT', 'TRANSFER_IN', 'INTEREST') THEN t.amount END AS credit,
           CASE WHEN t.txn_type IN ('WITHDRAWAL', 'TRANSFER_OUT', 'LOAN_EMI') THEN t.amount END AS debit,
           t.balance_after,
           SUM(CASE WHEN t.txn_type IN ('DEPOSIT', 'TRANSFER_IN', 'INTEREST') THEN t.amount ELSE -t.amount END)
               OVER (ORDER BY t.txn_time, t.txn_id) AS net_movement
      FROM transactions t
      JOIN accounts a ON a.account_id = t.account_id
     WHERE a.account_no = p_account_no
       AND t.txn_date BETWEEN IFNULL(p_from, '1000-01-01') AND IFNULL(p_to, '9999-12-31')
     ORDER BY t.txn_time, t.txn_id;
END$$

-- ---------------------------------------------------------------------------
-- sp_search_customers: dynamic SQL with PREPARE / EXECUTE / DEALLOCATE.
-- Only the conditions that were asked for are added to the statement.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_search_customers$$
CREATE PROCEDURE sp_search_customers(IN p_name VARCHAR(100), IN p_kyc VARCHAR(10))
BEGIN
    SET @sql = 'SELECT customer_id, full_name, email, phone, kyc_status FROM customers WHERE 1 = 1';
    SET @name_pattern = CONCAT('%', p_name, '%');
    SET @kyc = p_kyc;

    IF p_name IS NOT NULL AND p_name <> '' THEN
        SET @sql = CONCAT(@sql, ' AND full_name LIKE ?');
    END IF;
    IF p_kyc IS NOT NULL AND p_kyc <> '' THEN
        SET @sql = CONCAT(@sql, ' AND kyc_status = ?');
    END IF;
    SET @sql = CONCAT(@sql, ' ORDER BY full_name');

    PREPARE stmt FROM @sql;
    IF p_name IS NOT NULL AND p_name <> '' AND p_kyc IS NOT NULL AND p_kyc <> '' THEN
        EXECUTE stmt USING @name_pattern, @kyc;
    ELSEIF p_name IS NOT NULL AND p_name <> '' THEN
        EXECUTE stmt USING @name_pattern;
    ELSEIF p_kyc IS NOT NULL AND p_kyc <> '' THEN
        EXECUTE stmt USING @kyc;
    ELSE
        EXECUTE stmt;
    END IF;
    DEALLOCATE PREPARE stmt;
END$$

-- ---------------------------------------------------------------------------
-- Parameter-mode examples: OUT (branch report) and INOUT (add charges).
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_branch_report$$
CREATE PROCEDURE sp_branch_report(IN p_branch_id INT UNSIGNED, OUT p_accounts INT, OUT p_total DECIMAL(16,2))
BEGIN
    SELECT COUNT(*), IFNULL(SUM(balance), 0) INTO p_accounts, p_total
      FROM accounts WHERE branch_id = p_branch_id AND status <> 'CLOSED';
END$$

DROP PROCEDURE IF EXISTS sp_add_charges$$
CREATE PROCEDURE sp_add_charges(INOUT p_amount DECIMAL(14,2), IN p_percent DECIMAL(5,2))
BEGIN
    SET p_amount = ROUND(p_amount * (1 + p_percent / 100), 2);
END$$

DELIMITER ;
