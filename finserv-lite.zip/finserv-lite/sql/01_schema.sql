-- =============================================================================
-- FinServ Lite - 01_schema.sql
-- Topic    : DDL (CREATE DATABASE / TABLE), data types, constraints,
--            generated columns, JSON column, inline indexes.
-- Run order: 1 of 14   |   Needs: MySQL 8.0.31+ (CHECK, INTERSECT, JSON, CTE)
-- =============================================================================

DROP DATABASE IF EXISTS finserv_lite;
CREATE DATABASE finserv_lite
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;
USE finserv_lite;

-- ---------------------------------------------------------------- branches --
-- Types: INT UNSIGNED, VARCHAR, CHAR, DATE, BOOLEAN. Constraints: PK, UNIQUE,
-- NOT NULL, DEFAULT (expression default), CHECK with REGEXP_LIKE.
CREATE TABLE branches (
    branch_id    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    branch_name  VARCHAR(80)   NOT NULL,
    ifsc_code    CHAR(11)      NOT NULL,
    city         VARCHAR(60)   NOT NULL,
    opened_on    DATE          NOT NULL DEFAULT (CURRENT_DATE),
    is_active    BOOLEAN       NOT NULL DEFAULT TRUE,
    PRIMARY KEY (branch_id),
    CONSTRAINT uq_branches_ifsc UNIQUE (ifsc_code),
    CONSTRAINT ck_branches_ifsc CHECK (REGEXP_LIKE(ifsc_code, '^[A-Z]{4}0[A-Z0-9]{6}$', 'c'))
) ENGINE = InnoDB COMMENT = 'Bank branches';

-- --------------------------------------------------------------- customers --
-- Types: ENUM, JSON, TIMESTAMP. GENERATED ALWAYS AS ... STORED column.
CREATE TABLE customers (
    customer_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    first_name     VARCHAR(50)  NOT NULL,
    last_name      VARCHAR(50)  NOT NULL,
    full_name      VARCHAR(101) GENERATED ALWAYS AS (CONCAT(first_name, ' ', last_name)) STORED,
    email          VARCHAR(100) NOT NULL,
    phone          CHAR(10)     NOT NULL,
    date_of_birth  DATE         NOT NULL,
    kyc_status     ENUM('PENDING', 'VERIFIED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    address        JSON         NULL COMMENT 'e.g. {"street":"..","city":"..","pin":".."}',
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_id),
    CONSTRAINT uq_customers_email UNIQUE (email),
    CONSTRAINT ck_customers_phone CHECK (REGEXP_LIKE(phone, '^[6-9][0-9]{9}$'))
) ENGINE = InnoDB COMMENT = 'Bank customers';

-- ----------------------------------------------------------- account_types --
CREATE TABLE account_types (
    type_id        TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    type_name      VARCHAR(30)      NOT NULL,
    interest_rate  DECIMAL(4,2)     NOT NULL DEFAULT 0.00,
    min_balance    DECIMAL(12,2)    NOT NULL DEFAULT 0.00,
    PRIMARY KEY (type_id),
    CONSTRAINT uq_account_types_name UNIQUE (type_name),
    CONSTRAINT ck_account_types_rate CHECK (interest_rate BETWEEN 0 AND 15),
    CONSTRAINT ck_account_types_min  CHECK (min_balance >= 0)
) ENGINE = InnoDB COMMENT = 'Savings, current, salary, ...';

-- ---------------------------------------------------------------- accounts --
-- Foreign keys with ON DELETE RESTRICT, composite index, CHECK on balance.
CREATE TABLE accounts (
    account_id     INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    account_no     CHAR(12)      NOT NULL,
    customer_id    INT UNSIGNED  NOT NULL,
    branch_id      INT UNSIGNED  NOT NULL,
    type_id        TINYINT UNSIGNED NOT NULL,
    balance        DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    status         ENUM('ACTIVE', 'DORMANT', 'FROZEN', 'CLOSED') NOT NULL DEFAULT 'ACTIVE',
    opened_on      DATE          NOT NULL DEFAULT (CURRENT_DATE),
    last_activity  DATETIME      NULL,
    PRIMARY KEY (account_id),
    CONSTRAINT uq_accounts_no UNIQUE (account_no),
    KEY idx_accounts_customer (customer_id),
    KEY idx_accounts_branch_status (branch_id, status),
    KEY idx_accounts_type (type_id),
    CONSTRAINT ck_accounts_no      CHECK (REGEXP_LIKE(account_no, '^[0-9]{12}$')),
    CONSTRAINT ck_accounts_balance CHECK (balance >= 0),
    CONSTRAINT fk_accounts_customer FOREIGN KEY (customer_id) REFERENCES customers (customer_id) ON DELETE RESTRICT,
    CONSTRAINT fk_accounts_branch   FOREIGN KEY (branch_id)   REFERENCES branches (branch_id)   ON DELETE RESTRICT,
    CONSTRAINT fk_accounts_type     FOREIGN KEY (type_id)     REFERENCES account_types (type_id) ON DELETE RESTRICT
) ENGINE = InnoDB COMMENT = 'Customer accounts and their balance';

-- ------------------------------------------------------------ transactions --
-- Descending index (MySQL 8), stored generated DATE column, UUID link column.
CREATE TABLE transactions (
    txn_id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    account_id     INT UNSIGNED    NOT NULL,
    txn_type       ENUM('DEPOSIT', 'WITHDRAWAL', 'TRANSFER_IN', 'TRANSFER_OUT', 'INTEREST', 'LOAN_EMI') NOT NULL,
    amount         DECIMAL(14,2)   NOT NULL,
    balance_after  DECIMAL(14,2)   NOT NULL,
    transfer_ref   CHAR(36)        NULL COMMENT 'UUID shared by the two legs of a transfer',
    description    VARCHAR(200)    NULL,
    txn_time       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Always supply NOW() on INSERT (see sp_post_entry)',
    txn_date       DATE GENERATED ALWAYS AS (DATE(txn_time)) STORED,
    PRIMARY KEY (txn_id),
    KEY idx_txn_account_time (account_id, txn_time DESC),
    KEY idx_txn_date (txn_date),
    KEY idx_txn_ref (transfer_ref),
    CONSTRAINT ck_txn_amount CHECK (amount > 0),
    CONSTRAINT fk_txn_account FOREIGN KEY (account_id) REFERENCES accounts (account_id) ON DELETE RESTRICT
) ENGINE = InnoDB COMMENT = 'Append-only ledger of every money movement';

-- ------------------------------------------------------------------- loans --
CREATE TABLE loans (
    loan_id      INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    customer_id  INT UNSIGNED  NOT NULL,
    account_id   INT UNSIGNED  NOT NULL COMMENT 'Account that receives the money and pays the EMI',
    principal    DECIMAL(12,2) NOT NULL,
    annual_rate  DECIMAL(5,2)  NOT NULL,
    months       SMALLINT UNSIGNED NOT NULL,
    emi          DECIMAL(12,2) NULL COMMENT 'Filled by a trigger using fn_calculate_emi',
    status       ENUM('APPLIED', 'ACTIVE', 'CLOSED', 'REJECTED') NOT NULL DEFAULT 'APPLIED',
    applied_on   DATE          NOT NULL DEFAULT (CURRENT_DATE),
    PRIMARY KEY (loan_id),
    KEY idx_loans_customer (customer_id),
    KEY idx_loans_account (account_id),
    CONSTRAINT ck_loans_principal CHECK (principal > 0),
    CONSTRAINT ck_loans_rate      CHECK (annual_rate BETWEEN 0 AND 40),
    CONSTRAINT ck_loans_months    CHECK (months BETWEEN 1 AND 360),
    CONSTRAINT fk_loans_customer FOREIGN KEY (customer_id) REFERENCES customers (customer_id) ON DELETE RESTRICT,
    CONSTRAINT fk_loans_account  FOREIGN KEY (account_id)  REFERENCES accounts (account_id)  ON DELETE RESTRICT
) ENGINE = InnoDB COMMENT = 'Loans taken by customers';

-- ----------------------------------------------------------- loan_payments --
CREATE TABLE loan_payments (
    payment_id      INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    loan_id         INT UNSIGNED  NOT NULL,
    paid_on         DATE          NOT NULL DEFAULT (CURRENT_DATE),
    amount          DECIMAL(12,2) NOT NULL,
    principal_part  DECIMAL(12,2) NOT NULL,
    interest_part   DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (payment_id),
    KEY idx_loan_payments_loan (loan_id),
    CONSTRAINT ck_loan_payments_amount CHECK (amount > 0 AND principal_part >= 0 AND interest_part >= 0),
    CONSTRAINT fk_loan_payments_loan FOREIGN KEY (loan_id) REFERENCES loans (loan_id) ON DELETE RESTRICT
) ENGINE = InnoDB COMMENT = 'EMI payments made against loans';

-- --------------------------------------------------------------- audit_log --
-- Filled by triggers; stores JSON snapshots of old and new rows.
CREATE TABLE audit_log (
    audit_id    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    table_name  VARCHAR(40)     NOT NULL,
    action      ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    record_id   BIGINT UNSIGNED NOT NULL,
    old_data    JSON            NULL,
    new_data    JSON            NULL,
    changed_by  VARCHAR(100)    NOT NULL,
    changed_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (audit_id),
    KEY idx_audit_table_record (table_name, record_id)
) ENGINE = InnoDB COMMENT = 'Trigger-maintained audit trail';
