-- =============================================================================
-- FinServ Lite - 12_transactions_tcl.sql
-- Topic    : Transaction control (TCL) - autocommit, START TRANSACTION, COMMIT,
--            ROLLBACK, SAVEPOINT, isolation levels, row locks (FOR UPDATE /
--            FOR SHARE / NOWAIT / SKIP LOCKED), LOCK TABLES, GET DIAGNOSTICS.
-- Run order: 12 of 14
-- Safe     : every change below is rolled back or happens on a scratch table.
-- =============================================================================
USE finserv_lite;

-- ---- 1. ROLLBACK undoes everything since START TRANSACTION -------------------------
SELECT phone FROM customers WHERE customer_id = 1;                 -- before
START TRANSACTION;
UPDATE customers SET phone = '9000000001' WHERE customer_id = 1;
SELECT phone AS inside_transaction FROM customers WHERE customer_id = 1;
ROLLBACK;
SELECT phone AS after_rollback FROM customers WHERE customer_id = 1;   -- unchanged

-- ---- 2. COMMIT makes changes permanent (shown on a scratch table) -----------------------
CREATE TABLE tx_demo (id INT PRIMARY KEY, note VARCHAR(30)) ENGINE = InnoDB;
START TRANSACTION;
INSERT INTO tx_demo VALUES (1, 'committed row');
COMMIT;

-- ---- 3. SAVEPOINT: roll back only part of a transaction -----------------------------------
START TRANSACTION;
INSERT INTO tx_demo VALUES (2, 'kept');
SAVEPOINT after_kept;
INSERT INTO tx_demo VALUES (3, 'discarded');
SAVEPOINT after_discarded;
INSERT INTO tx_demo VALUES (4, 'also discarded');
ROLLBACK TO SAVEPOINT after_kept;          -- undoes rows 3 and 4 only
RELEASE SAVEPOINT after_kept;
COMMIT;
SELECT * FROM tx_demo ORDER BY id;         -- rows 1 and 2

-- ---- 4. autocommit: with it OFF every statement joins one open transaction ------------------
SELECT @@autocommit AS autocommit_now;
SET autocommit = 0;
INSERT INTO tx_demo VALUES (5, 'needs commit');
ROLLBACK;
SET autocommit = 1;
SELECT COUNT(*) AS rows_after_autocommit_demo FROM tx_demo;   -- still 2

-- ---- 5. Isolation levels -------------------------------------------------------------------------
SELECT @@transaction_isolation AS default_level;                         -- REPEATABLE-READ
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
SELECT @@transaction_isolation AS session_level;
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;                    -- strictest level
SELECT @@transaction_isolation AS session_level_now;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;                 -- back to the default
-- SET TRANSACTION ISOLATION LEVEL ... (without SESSION) applies only to the NEXT transaction
-- and is not shown by @@transaction_isolation.
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT COUNT(*) AS rows_seen FROM accounts;
COMMIT;

-- ---- 6. Row locks --------------------------------------------------------------------------------------
START TRANSACTION;
SELECT account_id, balance FROM accounts WHERE account_id = 1 FOR UPDATE;           -- exclusive lock
SELECT account_id, balance FROM accounts WHERE account_id = 2 FOR SHARE;            -- shared (read) lock
SELECT account_id FROM accounts WHERE status = 'ACTIVE' ORDER BY account_id LIMIT 2
    FOR UPDATE SKIP LOCKED;                                                         -- skip rows locked by others
SELECT account_id FROM accounts WHERE account_id = 3 FOR UPDATE NOWAIT;             -- error at once instead of waiting
COMMIT;

-- ---- 7. LOCK TABLES (table-level, rarely needed with InnoDB) ----------------------------------------------
LOCK TABLES tx_demo WRITE;
INSERT INTO tx_demo VALUES (6, 'under table lock');
UNLOCK TABLES;
DROP TABLE tx_demo;

-- ---- 8. Catching errors: GET DIAGNOSTICS in a wrapper procedure ----------------------------------------------
-- sp_try_transfer never fails; it returns 'OK' or the error text, which is how an application
-- (or a test) can see why sp_transfer rejected a request.
DELIMITER $$
DROP PROCEDURE IF EXISTS sp_try_transfer$$
CREATE PROCEDURE sp_try_transfer(IN p_from CHAR(12), IN p_to CHAR(12), IN p_amount DECIMAL(14,2), OUT p_result VARCHAR(255))
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 p_result = MESSAGE_TEXT;
    END;
    SET p_result = 'OK';
    CALL sp_transfer(p_from, p_to, p_amount, 'try');
END$$
DELIMITER ;

SET @acc1  = (SELECT account_no FROM accounts WHERE account_id = 1);
SET @acc7  = (SELECT account_no FROM accounts WHERE account_id = 7);    -- student account, low balance
SET @acc10 = (SELECT account_no FROM accounts WHERE account_id = 10);   -- FROZEN account

CALL sp_try_transfer(@acc7, @acc1, 99999999.00, @r1);  SELECT @r1 AS insufficient_funds;
CALL sp_try_transfer(@acc1, @acc1, 10.00, @r2);        SELECT @r2 AS same_account;
CALL sp_try_transfer(@acc1, '000000000000', 10.00, @r3); SELECT @r3 AS unknown_account;
CALL sp_try_transfer(@acc10, @acc1, 10.00, @r4);       SELECT @r4 AS frozen_source;
CALL sp_try_transfer(@acc1, @acc7, 0, @r5);            SELECT @r5 AS zero_amount;

-- Nothing above changed any balance: each failure rolled back inside sp_transfer.
SELECT COUNT(*) AS ledger_rows FROM transactions;

-- ---- 9. Two-session experiments (run in two terminals; not scripted) -----------------------------------------------
-- Session A: START TRANSACTION; SELECT * FROM accounts WHERE account_id = 1 FOR UPDATE;
-- Session B: UPDATE accounts SET balance = balance WHERE account_id = 1;   -- waits (lock wait)
-- Session A: COMMIT;                                                       -- B continues
-- Deadlock: A locks account 1 then 2; B locks account 2 then 1 -> MySQL rolls one back (error 1213).
--           sp_transfer avoids this by always locking the lower account_id first.
