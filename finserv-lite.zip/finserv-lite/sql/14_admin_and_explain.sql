-- =============================================================================
-- FinServ Lite - 14_admin_and_explain.sql
-- Topic    : EXPLAIN / EXPLAIN ANALYZE, index hints, SHOW commands,
--            INFORMATION_SCHEMA, ANALYZE TABLE, variables, backup commands.
-- Run order: 14 of 14
-- =============================================================================
USE finserv_lite;

-- ---- 1. EXPLAIN: how will MySQL run this query? ----------------------------------------
EXPLAIN SELECT * FROM accounts WHERE customer_id = 1;                                -- uses idx_accounts_customer
EXPLAIN SELECT * FROM transactions WHERE account_id = 1 ORDER BY txn_time DESC LIMIT 5;   -- descending index, no filesort
EXPLAIN FORMAT = TREE
SELECT c.full_name, SUM(a.balance) FROM customers c JOIN accounts a ON a.customer_id = c.customer_id GROUP BY c.customer_id;
EXPLAIN ANALYZE SELECT COUNT(*) FROM transactions WHERE txn_date BETWEEN '2026-05-01' AND '2026-05-31';

-- A query that cannot use an index: a function on the column hides it.
EXPLAIN SELECT * FROM transactions WHERE YEAR(txn_date) = 2026 AND MONTH(txn_date) = 5;     -- full scan
EXPLAIN SELECT * FROM transactions WHERE txn_date >= '2026-05-01' AND txn_date < '2026-06-01'; -- range scan

-- ---- 2. Index hints ------------------------------------------------------------------------
SELECT COUNT(*) FROM accounts USE INDEX (idx_accounts_branch_status) WHERE branch_id = 1;
SELECT COUNT(*) FROM accounts FORCE INDEX (idx_accounts_customer) WHERE customer_id = 1;
SELECT COUNT(*) FROM accounts IGNORE INDEX (idx_accounts_customer) WHERE customer_id = 1;

-- ---- 3. SHOW commands ---------------------------------------------------------------------------
SHOW TABLES;
SHOW CREATE TABLE accounts\G
SHOW INDEX FROM transactions;
SHOW TABLE STATUS LIKE 'transactions';
SHOW PROCEDURE STATUS WHERE Db = 'finserv_lite';
SHOW FUNCTION STATUS  WHERE Db = 'finserv_lite';
SHOW TRIGGERS;
SHOW EVENTS;
SHOW VARIABLES LIKE 'event_scheduler';

-- ---- 4. INFORMATION_SCHEMA: the database describing itself --------------------------------------------
SELECT TABLE_NAME, TABLE_ROWS, ROUND(DATA_LENGTH / 1024, 1) AS data_kb, ROUND(INDEX_LENGTH / 1024, 1) AS index_kb
FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'finserv_lite' AND TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;

SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_KEY, EXTRA
FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'finserv_lite' AND TABLE_NAME = 'customers' ORDER BY ORDINAL_POSITION;

SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'finserv_lite' AND REFERENCED_TABLE_NAME IS NOT NULL ORDER BY TABLE_NAME;

SELECT TABLE_NAME, CONSTRAINT_NAME, CHECK_CLAUSE
FROM information_schema.CHECK_CONSTRAINTS cc JOIN information_schema.TABLE_CONSTRAINTS tc USING (CONSTRAINT_SCHEMA, CONSTRAINT_NAME)
WHERE CONSTRAINT_SCHEMA = 'finserv_lite' ORDER BY TABLE_NAME, CONSTRAINT_NAME LIMIT 8;

-- ---- 5. Maintenance and variables --------------------------------------------------------------------------
ANALYZE TABLE accounts, transactions;               -- refresh index statistics
SELECT VERSION() AS mysql_version, @@sql_mode AS sql_mode, @@time_zone AS time_zone, @@character_set_database AS charset;
SELECT CURRENT_USER() AS who_am_i, DATABASE() AS current_db, CONNECTION_ID() AS connection_id, LAST_INSERT_ID() AS last_id;

-- ---- 6. Backup and restore (run in a shell, not in mysql) -----------------------------------------------------
--   mysqldump --single-transaction --routines --triggers --events -u root -p finserv_lite > finserv_lite_backup.sql
--   mysql -u root -p -e "CREATE DATABASE finserv_restore"
--   mysql -u root -p finserv_restore < finserv_lite_backup.sql
