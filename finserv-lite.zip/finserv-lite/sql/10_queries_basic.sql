-- =============================================================================
-- FinServ Lite - 10_queries_basic.sql
-- Topic    : SELECT basics - filtering, sorting, aggregates, GROUP BY / HAVING /
--            ROLLUP, string / number / date / conditional / JSON functions,
--            regular expressions, FULLTEXT search, calling routines.
-- Run order: 10 of 14
-- =============================================================================
USE finserv_lite;

-- 1. Projection, alias, DISTINCT, ORDER BY, LIMIT / OFFSET ---------------------
SELECT customer_id, full_name AS customer, email FROM customers ORDER BY last_name, first_name LIMIT 5;
SELECT DISTINCT city FROM branches ORDER BY city;
SELECT account_id, balance FROM accounts ORDER BY balance DESC LIMIT 3 OFFSET 2;   -- 3rd to 5th richest

-- 2. WHERE: comparison, AND / OR / NOT, IN, BETWEEN, LIKE, IS NULL, REGEXP -------------
SELECT full_name, kyc_status FROM customers WHERE kyc_status IN ('PENDING', 'REJECTED');
SELECT account_no, balance FROM accounts WHERE balance BETWEEN 50000 AND 200000 AND status = 'ACTIVE';
SELECT full_name FROM customers WHERE full_name LIKE 'A%' OR email LIKE '%@example.com' AND NOT kyc_status = 'PENDING';
SELECT account_id FROM accounts WHERE last_activity IS NULL;
SELECT full_name, phone FROM customers WHERE phone REGEXP '^9[0-9]{9}$' AND REGEXP_LIKE(email, '^[a-z]+\\.[a-z]+@');

-- 3. Aggregates, GROUP BY, HAVING, WITH ROLLUP, GROUP_CONCAT ------------------------------
SELECT COUNT(*) AS accounts, SUM(balance) AS total, ROUND(AVG(balance), 2) AS average,
       MIN(balance) AS smallest, MAX(balance) AS largest
FROM accounts;

SELECT type_id, COUNT(*) AS accounts, SUM(balance) AS total
FROM accounts
GROUP BY type_id
HAVING COUNT(*) >= 2                       -- HAVING filters groups, WHERE filters rows
ORDER BY total DESC;

SELECT branch_id, status, COUNT(*) AS accounts, SUM(balance) AS total
FROM accounts
GROUP BY branch_id, status WITH ROLLUP;    -- adds subtotal rows (NULL = "all")

SELECT b.city, GROUP_CONCAT(DISTINCT b.branch_name ORDER BY b.branch_name SEPARATOR ' | ') AS branches
FROM branches b GROUP BY b.city;

-- 4. String functions -----------------------------------------------------------------------
SELECT UPPER(last_name)                          AS upper_name,
       LOWER(email)                              AS lower_email,
       CONCAT_WS(' - ', first_name, last_name)   AS joined,
       CHAR_LENGTH(full_name)                    AS name_length,
       LEFT(first_name, 1)                       AS initial,
       SUBSTRING_INDEX(email, '@', -1)           AS email_domain,
       LPAD(customer_id, 6, '0')                 AS padded_id,
       REPLACE(phone, SUBSTRING(phone, 4, 4), '****') AS masked_phone,
       REVERSE(first_name)                       AS reversed,
       TRIM('  padded  ')                        AS trimmed
FROM customers WHERE customer_id <= 3;

-- 5. Numeric functions ------------------------------------------------------------------------
SELECT ROUND(3.14159, 2) AS rounded, CEIL(4.2) AS ceil_value, FLOOR(4.8) AS floor_value,
       ABS(-250) AS absolute, MOD(17, 5) AS remainder, POW(2, 10) AS power_value,
       SQRT(144) AS root, TRUNCATE(9.999, 1) AS truncated, SIGN(-5) AS sign_value;

-- 6. Date and time functions --------------------------------------------------------------------
SELECT NOW() AS now_value, CURDATE() AS today, YEAR(CURDATE()) AS year_now,
       DATE_FORMAT('2026-04-06', '%W, %d %M %Y')            AS formatted,
       DATE_ADD('2026-01-31', INTERVAL 1 MONTH)             AS plus_month,
       LAST_DAY('2026-02-10')                               AS month_end,
       DATEDIFF('2026-12-25', '2026-10-10')                 AS days_between,
       TIMESTAMPDIFF(YEAR, '1990-04-12', CURDATE())         AS age_years,
       DAYNAME('2026-04-06') AS weekday_name, QUARTER('2026-08-15') AS quarter_no,
       STR_TO_DATE('06/04/2026', '%d/%m/%Y')                AS parsed_date;

-- 7. Conditional and NULL functions ----------------------------------------------------------------
SELECT full_name,
       CASE kyc_status WHEN 'VERIFIED' THEN 'OK' WHEN 'PENDING' THEN 'WAIT' ELSE 'BLOCK' END AS kyc_flag,
       IF(fn_age_years(date_of_birth) >= 30, 'adult 30+', 'under 30') AS age_group,
       IFNULL(gender, 'unknown')                  AS gender_value,
       COALESCE(NULL, gender, 'n/a')              AS first_non_null,
       NULLIF(kyc_status, 'PENDING')              AS null_if_pending
FROM customers ORDER BY customer_id LIMIT 6;

-- 8. JSON functions ------------------------------------------------------------------------------------
SELECT customer_id,
       address ->> '$.city'                                 AS city,       -- ->> returns unquoted text
       JSON_EXTRACT(address, '$.pin')                       AS pin_json,
       JSON_CONTAINS_PATH(address, 'one', '$.landmark')     AS has_landmark,
       JSON_KEYS(address)                                   AS keys_list,
       JSON_LENGTH(address)                                 AS key_count
FROM customers WHERE customer_id IN (1, 2);

SELECT address ->> '$.city' AS city, COUNT(*) AS customers,
       JSON_ARRAYAGG(first_name) AS names                   -- aggregate rows into a JSON array
FROM customers GROUP BY address ->> '$.city' ORDER BY customers DESC, city;

-- 9. CAST / CONVERT and user variables ------------------------------------------------------------------
SELECT CAST('2026-04-06' AS DATE) AS as_date, CAST(19.99 AS SIGNED) AS as_int, CONVERT('42', UNSIGNED) AS as_unsigned;
SET @min_balance = 100000;
SELECT account_no, balance FROM accounts WHERE balance >= @min_balance ORDER BY balance DESC;

-- 10. FULLTEXT search (index ft_customers_name) ---------------------------------------------------------------
SELECT full_name, MATCH(first_name, last_name) AGAINST('Sharma Patel' IN NATURAL LANGUAGE MODE) AS score
FROM customers
WHERE MATCH(first_name, last_name) AGAINST('Sharma Patel' IN NATURAL LANGUAGE MODE);

SELECT full_name FROM customers WHERE MATCH(first_name, last_name) AGAINST('+Priya -Patel' IN BOOLEAN MODE);

-- 11. Calling the functions, views and procedures --------------------------------------------------------------
SELECT * FROM v_customer_accounts ORDER BY customer_id, account_id LIMIT 5;
SELECT * FROM v_branch_summary ORDER BY total_balance DESC;
SELECT * FROM v_customer_portfolio ORDER BY balance_rank LIMIT 5;
SELECT * FROM v_loan_status;
SELECT * FROM v_monthly_txn_summary WHERE txn_type = 'INTEREST' ORDER BY txn_year, txn_month;

CALL sp_search_customers('an', 'VERIFIED');                       -- dynamic SQL procedure
CALL sp_branch_report(1, @branch_accounts, @branch_total);        -- OUT parameters
SELECT @branch_accounts AS accounts_in_branch_1, @branch_total AS total_in_branch_1;
SET @charged = 1000.00;
CALL sp_add_charges(@charged, 18);                                -- INOUT parameter (adds 18 percent GST)
SELECT @charged AS amount_with_gst;
CALL sp_account_statement((SELECT account_no FROM accounts WHERE account_id = 1), '2026-04-01', '2026-06-30');
