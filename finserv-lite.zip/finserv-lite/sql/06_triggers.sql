-- =============================================================================
-- FinServ Lite - 06_triggers.sql
-- Topic    : Triggers - BEFORE / AFTER, INSERT / UPDATE / DELETE, OLD and NEW,
--            SIGNAL to reject bad data, JSON_OBJECT snapshots for auditing.
-- Run order: 6 of 14
-- =============================================================================
USE finserv_lite;
DELIMITER $$

-- ------------------------------ customers ------------------------------------
-- BEFORE INSERT: validate age and clean the email before the row is stored.
DROP TRIGGER IF EXISTS trg_customers_bi$$
CREATE TRIGGER trg_customers_bi BEFORE INSERT ON customers
FOR EACH ROW
BEGIN
    IF fn_age_years(NEW.date_of_birth) < 18 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Customer must be at least 18 years old';
    END IF;
    SET NEW.email = LOWER(TRIM(NEW.email));
END$$

DROP TRIGGER IF EXISTS trg_customers_bu$$
CREATE TRIGGER trg_customers_bu BEFORE UPDATE ON customers
FOR EACH ROW
BEGIN
    SET NEW.email = LOWER(TRIM(NEW.email));
END$$

DROP TRIGGER IF EXISTS trg_customers_ai$$
CREATE TRIGGER trg_customers_ai AFTER INSERT ON customers
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, new_data, changed_by)
    VALUES ('customers', 'INSERT', NEW.customer_id,
            JSON_OBJECT('name', NEW.full_name, 'email', NEW.email, 'kyc_status', NEW.kyc_status),
            CURRENT_USER());
END$$

-- AFTER UPDATE: log only when an important column really changed.
DROP TRIGGER IF EXISTS trg_customers_au$$
CREATE TRIGGER trg_customers_au AFTER UPDATE ON customers
FOR EACH ROW
BEGIN
    IF NOT (OLD.kyc_status <=> NEW.kyc_status AND OLD.email <=> NEW.email AND OLD.phone <=> NEW.phone) THEN
        INSERT INTO audit_log (table_name, action, record_id, old_data, new_data, changed_by)
        VALUES ('customers', 'UPDATE', NEW.customer_id,
                JSON_OBJECT('kyc_status', OLD.kyc_status, 'email', OLD.email, 'phone', OLD.phone),
                JSON_OBJECT('kyc_status', NEW.kyc_status, 'email', NEW.email, 'phone', NEW.phone),
                CURRENT_USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_customers_ad$$
CREATE TRIGGER trg_customers_ad AFTER DELETE ON customers
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, old_data, changed_by)
    VALUES ('customers', 'DELETE', OLD.customer_id,
            JSON_OBJECT('name', OLD.full_name, 'email', OLD.email, 'kyc_status', OLD.kyc_status),
            CURRENT_USER());
END$$

-- ------------------------------- accounts -------------------------------------
-- Balance changes are recorded in the ledger, so only STATUS changes are audited here.
DROP TRIGGER IF EXISTS trg_accounts_au$$
CREATE TRIGGER trg_accounts_au AFTER UPDATE ON accounts
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO audit_log (table_name, action, record_id, old_data, new_data, changed_by)
        VALUES ('accounts', 'UPDATE', NEW.account_id,
                JSON_OBJECT('status', OLD.status), JSON_OBJECT('status', NEW.status), CURRENT_USER());
    END IF;
END$$

-- Accounts are closed, never deleted.
DROP TRIGGER IF EXISTS trg_accounts_bd$$
CREATE TRIGGER trg_accounts_bd BEFORE DELETE ON accounts
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accounts cannot be deleted; close them instead';
END$$

-- ----------------------------- transactions ------------------------------------
-- AFTER INSERT: keep accounts.last_activity current (used by the dormancy event).
DROP TRIGGER IF EXISTS trg_transactions_ai$$
CREATE TRIGGER trg_transactions_ai AFTER INSERT ON transactions
FOR EACH ROW
BEGIN
    UPDATE accounts SET last_activity = NEW.txn_time WHERE account_id = NEW.account_id;
END$$

-- The ledger is append-only.
DROP TRIGGER IF EXISTS trg_transactions_bu$$
CREATE TRIGGER trg_transactions_bu BEFORE UPDATE ON transactions
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transactions cannot be changed';
END$$

DROP TRIGGER IF EXISTS trg_transactions_bd$$
CREATE TRIGGER trg_transactions_bd BEFORE DELETE ON transactions
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transactions cannot be deleted';
END$$

-- -------------------------------- loans -----------------------------------------
-- BEFORE INSERT: compute the EMI with the stored function.
DROP TRIGGER IF EXISTS trg_loans_bi$$
CREATE TRIGGER trg_loans_bi BEFORE INSERT ON loans
FOR EACH ROW
BEGIN
    IF NEW.emi IS NULL THEN
        SET NEW.emi = fn_calculate_emi(NEW.principal, NEW.annual_rate, NEW.months);
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_loans_au$$
CREATE TRIGGER trg_loans_au AFTER UPDATE ON loans
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO audit_log (table_name, action, record_id, old_data, new_data, changed_by)
        VALUES ('loans', 'UPDATE', NEW.loan_id,
                JSON_OBJECT('status', OLD.status), JSON_OBJECT('status', NEW.status), CURRENT_USER());
    END IF;
END$$

DELIMITER ;

SELECT TRIGGER_NAME, EVENT_MANIPULATION AS event, EVENT_OBJECT_TABLE AS on_table, ACTION_TIMING AS timing
FROM information_schema.TRIGGERS
WHERE TRIGGER_SCHEMA = 'finserv_lite'
ORDER BY EVENT_OBJECT_TABLE, ACTION_TIMING, EVENT_MANIPULATION;
