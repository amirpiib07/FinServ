-- =============================================================================
-- FinServ Lite - 11_queries_advanced.sql
-- Topic    : JOIN types, subqueries, set operations (UNION / INTERSECT / EXCEPT),
--            CTEs and RECURSIVE CTEs, window functions, LATERAL, JSON_TABLE,
--            pivot with conditional aggregation, ROLLUP with GROUPING().
-- Run order: 11 of 14   (MySQL 8.0.31+ for INTERSECT / EXCEPT)
-- =============================================================================
USE finserv_lite;

-- ============================== A. JOINS ======================================
-- A1 INNER JOIN across four tables
SELECT c.full_name, a.account_no, t.type_name, b.branch_name, a.balance
FROM customers c
INNER JOIN accounts a      ON a.customer_id = c.customer_id
INNER JOIN account_types t ON t.type_id = a.type_id
INNER JOIN branches b      ON b.branch_id = a.branch_id
WHERE a.status = 'ACTIVE'
ORDER BY a.balance DESC LIMIT 5;

-- A2 LEFT JOIN + IS NULL = "anti join": customers without any account
SELECT c.customer_id, c.full_name, c.kyc_status
FROM customers c
LEFT JOIN accounts a ON a.customer_id = c.customer_id
WHERE a.account_id IS NULL;

-- A3 RIGHT JOIN: every branch, even those without accounts
SELECT b.branch_name, b.is_active, COUNT(a.account_id) AS accounts
FROM accounts a
RIGHT JOIN branches b ON b.branch_id = a.branch_id
GROUP BY b.branch_id, b.branch_name, b.is_active
ORDER BY b.branch_id;

-- A4 CROSS JOIN: every account type offered at every active branch
SELECT b.branch_name, t.type_name
FROM branches b CROSS JOIN account_types t
WHERE b.is_active
ORDER BY b.branch_name, t.type_name LIMIT 6;

-- A5 SELF JOIN: pairs of customers living in the same city
SELECT c1.full_name AS customer_1, c2.full_name AS customer_2, c1.address ->> '$.city' AS city
FROM customers c1
JOIN customers c2 ON c1.address ->> '$.city' = c2.address ->> '$.city' AND c1.customer_id < c2.customer_id;

-- A6 Self join on the ledger: both legs of every transfer (shared UUID)
SELECT o.txn_time, o.amount, o.account_id AS from_account, i.account_id AS to_account
FROM transactions o
JOIN transactions i ON i.transfer_ref = o.transfer_ref AND i.txn_type = 'TRANSFER_IN'
WHERE o.txn_type = 'TRANSFER_OUT'
ORDER BY o.txn_time;

-- ============================ B. SUBQUERIES ===================================
-- B1 Scalar subquery: accounts above the bank-wide average balance
SELECT account_no, balance FROM accounts WHERE balance > (SELECT AVG(balance) FROM accounts) ORDER BY balance DESC;

-- B2 IN / NOT IN
SELECT full_name FROM customers WHERE customer_id IN (SELECT customer_id FROM loans WHERE status = 'ACTIVE');

-- B3 EXISTS / NOT EXISTS
SELECT full_name FROM customers c
WHERE EXISTS (SELECT 1 FROM accounts a WHERE a.customer_id = c.customer_id AND a.type_id = 2);
SELECT full_name FROM customers c
WHERE NOT EXISTS (SELECT 1 FROM loans l WHERE l.customer_id = c.customer_id) AND c.kyc_status = 'VERIFIED';

-- B4 Correlated subquery: accounts richer than the average of their own branch
SELECT a.account_no, a.branch_id, a.balance
FROM accounts a
WHERE a.balance > (SELECT AVG(x.balance) FROM accounts x WHERE x.branch_id = a.branch_id)
ORDER BY a.branch_id, a.balance DESC;

-- B5 ANY / ALL
SELECT account_no, balance FROM accounts WHERE balance > ALL (SELECT balance FROM accounts WHERE type_id = 4);
SELECT account_no, balance FROM accounts WHERE balance < ANY (SELECT balance FROM accounts WHERE type_id = 2) ORDER BY balance LIMIT 3;

-- B6 Subquery in SELECT list and in FROM (derived table)
SELECT c.full_name,
       (SELECT COUNT(*) FROM accounts a WHERE a.customer_id = c.customer_id) AS accounts,
       fn_customer_total_balance(c.customer_id) AS total_balance
FROM customers c ORDER BY total_balance DESC LIMIT 5;

SELECT d.city, d.customers, ROUND(100 * d.customers / SUM(d.customers) OVER (), 1) AS percent_of_all
FROM (SELECT address ->> '$.city' AS city, COUNT(*) AS customers FROM customers GROUP BY address ->> '$.city') AS d
ORDER BY d.customers DESC, d.city;

-- ===================== C. SET OPERATIONS (UNION, INTERSECT, EXCEPT) ==============
SELECT customer_id, 'has savings' AS note FROM accounts WHERE type_id = 1
UNION                                                       -- removes duplicates
SELECT customer_id, 'has savings' FROM accounts WHERE type_id = 3
ORDER BY customer_id;

SELECT 'deposit' AS kind, COUNT(*) AS n FROM transactions WHERE txn_type = 'DEPOSIT'
UNION ALL                                                   -- keeps everything
SELECT 'withdrawal', COUNT(*) FROM transactions WHERE txn_type = 'WITHDRAWAL';

SELECT customer_id FROM accounts WHERE type_id = 1
INTERSECT                                                   -- in both result sets
SELECT customer_id FROM accounts WHERE type_id = 2;

SELECT customer_id FROM accounts
EXCEPT                                                      -- in the first but not the second
SELECT customer_id FROM loans
ORDER BY customer_id;

-- ================================ D. CTEs =====================================
-- D1 Chained CTEs: customers whose balance is above their segment average
WITH totals AS (
    SELECT c.customer_id, c.full_name, fn_customer_total_balance(c.customer_id) AS total
    FROM customers c
),
segments AS (
    SELECT t.*, fn_customer_segment(t.total) AS segment FROM totals t
)
SELECT s.full_name, s.total, s.segment,
       ROUND(AVG(s.total) OVER (PARTITION BY s.segment), 2) AS segment_average
FROM segments s
WHERE s.total > 0
ORDER BY s.segment, s.total DESC;

-- D2 RECURSIVE CTE: month-by-month repayment schedule of loan 1 (first 3 months and the last)
WITH RECURSIVE schedule (month_no, opening_balance, interest, principal_paid, closing_balance, emi, rate, months) AS (
    SELECT 1,
           CAST(l.principal AS DECIMAL(14,2)),
           ROUND(l.principal * l.annual_rate / 1200, 2),
           l.emi - ROUND(l.principal * l.annual_rate / 1200, 2),
           CAST(l.principal - (l.emi - ROUND(l.principal * l.annual_rate / 1200, 2)) AS DECIMAL(14,2)),
           l.emi, l.annual_rate, l.months
    FROM loans l WHERE l.loan_id = 1
    UNION ALL
    SELECT month_no + 1,
           closing_balance,
           ROUND(closing_balance * rate / 1200, 2),
           emi - ROUND(closing_balance * rate / 1200, 2),
           CAST(closing_balance - (emi - ROUND(closing_balance * rate / 1200, 2)) AS DECIMAL(14,2)),
           emi, rate, months
    FROM schedule WHERE month_no < months
)
SELECT month_no, opening_balance, interest, principal_paid, closing_balance
FROM schedule WHERE month_no <= 3 OR month_no = months;

-- D3 RECURSIVE CTE as a calendar: deposits per month, including months with none
WITH RECURSIVE months (first_day) AS (
    SELECT DATE('2026-03-01')
    UNION ALL
    SELECT first_day + INTERVAL 1 MONTH FROM months WHERE first_day < '2026-10-01'
)
SELECT DATE_FORMAT(m.first_day, '%Y-%m') AS month,
       COUNT(t.txn_id)                   AS deposits,
       IFNULL(SUM(t.amount), 0)          AS deposit_amount
FROM months m
LEFT JOIN transactions t
       ON t.txn_type = 'DEPOSIT' AND t.txn_date >= m.first_day AND t.txn_date < m.first_day + INTERVAL 1 MONTH
GROUP BY m.first_day
ORDER BY m.first_day;

-- ========================== E. WINDOW FUNCTIONS ================================
-- E1 Ranking: ROW_NUMBER / RANK / DENSE_RANK / NTILE / PERCENT_RANK, with a named window
SELECT a.branch_id, a.account_no, a.balance,
       ROW_NUMBER()   OVER w AS row_no,
       RANK()         OVER w AS rank_no,
       DENSE_RANK()   OVER w AS dense_rank_no,
       NTILE(2)       OVER w AS half,
       ROUND(PERCENT_RANK() OVER w, 2) AS pct_rank
FROM accounts a
WINDOW w AS (PARTITION BY a.branch_id ORDER BY a.balance DESC)
ORDER BY a.branch_id, row_no;

-- E2 Latest transaction per account (ROW_NUMBER + filter in an outer query)
SELECT account_id, txn_time, txn_type, amount
FROM (SELECT t.*, ROW_NUMBER() OVER (PARTITION BY account_id ORDER BY txn_time DESC, txn_id DESC) AS rn
      FROM transactions t) x
WHERE rn = 1 ORDER BY account_id;

-- E3 LAG / LEAD / running total / moving average / FIRST_VALUE for one account
SELECT txn_id, txn_time, txn_type, amount, balance_after,
       LAG(balance_after)  OVER w                      AS previous_balance,
       LEAD(txn_time)      OVER w                      AS next_txn_time,
       SUM(amount) OVER (w ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_amount,
       ROUND(AVG(amount) OVER (w ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 2) AS moving_avg_3,
       FIRST_VALUE(balance_after) OVER w               AS first_balance
FROM transactions
WHERE account_id = 1
WINDOW w AS (ORDER BY txn_time, txn_id)
LIMIT 8;

-- E4 Month-over-month change of total deposits (LAG over an aggregate)
SELECT txn_month, total_deposits,
       total_deposits - LAG(total_deposits) OVER (ORDER BY txn_month) AS change_vs_previous
FROM (SELECT DATE_FORMAT(txn_date, '%Y-%m') AS txn_month, SUM(amount) AS total_deposits
      FROM transactions WHERE txn_type = 'DEPOSIT' GROUP BY DATE_FORMAT(txn_date, '%Y-%m')) m
ORDER BY txn_month;

-- ============================ F. LATERAL JOIN ==================================
-- The two most recent transactions of each of the first three accounts
SELECT a.account_no, x.txn_time, x.txn_type, x.amount
FROM accounts a
JOIN LATERAL (SELECT t.txn_time, t.txn_type, t.amount
              FROM transactions t WHERE t.account_id = a.account_id
              ORDER BY t.txn_time DESC, t.txn_id DESC LIMIT 2) AS x ON TRUE
WHERE a.account_id <= 3
ORDER BY a.account_id, x.txn_time DESC;

-- ============================ G. JSON_TABLE ====================================
-- Turn the JSON address column into ordinary rows and columns
SELECT c.customer_id, c.full_name, jt.street, jt.city, jt.pin, jt.landmark
FROM customers c,
     JSON_TABLE(c.address, '$' COLUMNS (
         street   VARCHAR(60) PATH '$.street',
         city     VARCHAR(40) PATH '$.city',
         pin      CHAR(6)     PATH '$.pin',
         landmark VARCHAR(40) PATH '$.landmark' DEFAULT '"-"' ON EMPTY
     )) AS jt
WHERE c.customer_id <= 4;

-- ===================== H. PIVOT with conditional aggregation ====================
SELECT DATE_FORMAT(txn_date, '%Y-%m') AS month,
       SUM(CASE WHEN txn_type IN ('DEPOSIT', 'TRANSFER_IN', 'INTEREST') THEN amount ELSE 0 END) AS money_in,
       SUM(CASE WHEN txn_type IN ('WITHDRAWAL', 'TRANSFER_OUT', 'LOAN_EMI') THEN amount ELSE 0 END) AS money_out,
       SUM(CASE WHEN txn_type IN ('DEPOSIT', 'TRANSFER_IN', 'INTEREST') THEN amount ELSE -amount END) AS net
FROM transactions
GROUP BY DATE_FORMAT(txn_date, '%Y-%m')
ORDER BY month;

-- ================== I. ROLLUP with GROUPING() labels =============================
SELECT IF(GROUPING(b.branch_name), 'ALL BRANCHES', b.branch_name) AS branch,
       IF(GROUPING(a.status),      'ALL STATUSES', a.status)      AS status,
       COUNT(*) AS accounts, SUM(a.balance) AS total
FROM accounts a JOIN branches b ON b.branch_id = a.branch_id
GROUP BY b.branch_name, a.status WITH ROLLUP;
