-- =============================================================================
-- FinServ Lite - 08_sample_data.sql
-- Topic    : DML - INSERT (multi-row, INSERT IGNORE, ON DUPLICATE KEY UPDATE,
--            REPLACE, INSERT ... SELECT), UPDATE, DELETE with a subquery,
--            JSON_SET, and how triggers react to these statements.
-- Run order: 8 of 14
-- =============================================================================
USE finserv_lite;

-- ---- Multi-row INSERT --------------------------------------------------------
INSERT INTO branches (branch_name, ifsc_code, city, opened_on, is_active) VALUES
    ('Surat Main',        'FINS0000001', 'Surat',     '2010-04-01', TRUE),
    ('Mumbai Fort',       'FINS0000002', 'Mumbai',    '2008-07-15', TRUE),
    ('Delhi Connaught',   'FINS0000003', 'Delhi',     '2012-01-10', TRUE),
    ('Chennai Anna Nagar','FINS0000004', 'Chennai',   '2015-09-05', TRUE),
    ('Bengaluru MG Road', 'FINS0000005', 'Bengaluru', '2019-03-20', FALSE);

INSERT INTO account_types (type_name, interest_rate, min_balance) VALUES
    ('Savings', 3.50, 1000.00),
    ('Current', 0.00, 5000.00),
    ('Salary',  4.00,    0.00);

-- ---- ON DUPLICATE KEY UPDATE (upsert) and INSERT IGNORE ----------------------------
INSERT INTO account_types (type_name, interest_rate, min_balance) VALUES ('Student', 2.50, 0.00)
ON DUPLICATE KEY UPDATE interest_rate = VALUES(interest_rate);   -- inserts: new name
INSERT INTO account_types (type_name, interest_rate, min_balance) VALUES ('Savings', 3.75, 1000.00)
ON DUPLICATE KEY UPDATE interest_rate = VALUES(interest_rate);   -- updates: name exists
INSERT IGNORE INTO account_types (type_name, interest_rate) VALUES ('Current', 9.99);  -- duplicate silently skipped
REPLACE INTO account_types (type_id, type_name, interest_rate, min_balance)
VALUES (3, 'Salary', 4.00, 0.00);                                -- delete + insert on key match

-- Triggers at work: trg_customers_bi trims/lower-cases emails and rejects minors.
INSERT INTO customers (first_name, last_name, gender, email, phone, date_of_birth, kyc_status, address) VALUES
    ('Aarav',  'Sharma', 'M', '  Aarav.Sharma@Example.com ', '9876543210', '1990-04-12', 'VERIFIED',
        JSON_OBJECT('street', '12 Marine Drive',  'city', 'Mumbai',    'pin', '400001')),
    ('Priya',  'Patel',  'F', 'priya.patel@example.com',  '9123456780', '1988-09-23', 'VERIFIED',
        JSON_OBJECT('street', '8 Ring Road',      'city', 'Surat',     'pin', '395002')),
    ('Rohan',  'Mehta',  'M', 'rohan.mehta@example.com',  '9988776655', '1995-01-30', 'VERIFIED',
        JSON_OBJECT('street', '21 CG Road',       'city', 'Ahmedabad', 'pin', '380009')),
    ('Ananya', 'Iyer',   'F', 'ananya.iyer@example.com',  '9012345678', '1992-07-19', 'VERIFIED',
        JSON_OBJECT('street', '5 Mount Road',     'city', 'Chennai',   'pin', '600002')),
    ('Vikram', 'Singh',  'M', 'vikram.singh@example.com', '9898989898', '1985-11-02', 'VERIFIED',
        JSON_OBJECT('street', '17 Janpath',       'city', 'Delhi',     'pin', '110001')),
    ('Neha',   'Gupta',  'F', 'neha.gupta@example.com',   '8765432109', '1998-03-08', 'VERIFIED',
        JSON_OBJECT('street', '3 FC Road',        'city', 'Pune',      'pin', '411004')),
    ('Karan',  'Desai',  'M', 'karan.desai@example.com',  '9765432101', '1993-12-25', 'VERIFIED',
        JSON_OBJECT('street', '44 Athwa Lines',   'city', 'Surat',     'pin', '395001')),
    ('Sneha',  'Reddy',  'F', 'sneha.reddy@example.com',  '9345678901', '1991-06-14', 'VERIFIED',
        JSON_OBJECT('street', '9 Banjara Hills',  'city', 'Hyderabad', 'pin', '500034')),
    ('Arjun',  'Nair',   'M', 'arjun.nair@example.com',   '9456789012', '2000-02-29', 'PENDING',
        JSON_OBJECT('street', '2 MG Road',        'city', 'Kochi',     'pin', '682016')),
    ('Meera',  'Joshi',  'F', 'meera.joshi@example.com',  '9567890123', '1987-08-05', 'REJECTED',
        JSON_OBJECT('street', '6 MI Road',        'city', 'Jaipur',    'pin', '302001')),
    ('Imran',  'Khan',   'M', 'imran.khan@example.com',   '9678901234', '1994-10-17', 'VERIFIED',
        JSON_OBJECT('street', '15 Hazratganj',    'city', 'Lucknow',   'pin', '226001')),
    ('Divya',  'Menon',  'F', 'divya.menon@example.com',  '9789012345', '1996-05-21', 'PENDING',
        JSON_OBJECT('street', '30 Indiranagar',   'city', 'Bengaluru', 'pin', '560038'));

-- ---- INSERT ... SELECT: copy rows into another table ---------------------------------
CREATE TABLE customers_backup LIKE customers;
-- Generated columns cannot be inserted, so the column list is written out.
INSERT INTO customers_backup (customer_id, first_name, last_name, gender, email, phone,
                              date_of_birth, kyc_status, address, created_at)
SELECT customer_id, first_name, last_name, gender, email, phone,
       date_of_birth, kyc_status, address, created_at
FROM customers
WHERE kyc_status = 'VERIFIED';
SELECT COUNT(*) AS rows_copied FROM customers_backup;
DROP TABLE customers_backup;

-- ---- UPDATE: simple, with ORDER BY ... LIMIT, and JSON_SET -----------------------------
UPDATE customers SET kyc_status = 'VERIFIED' WHERE first_name = 'Arjun';       -- audited by trg_customers_au
UPDATE customers SET phone = '9000011111' WHERE customer_id = 12 ORDER BY customer_id LIMIT 1;
UPDATE customers
   SET address = JSON_SET(address, '$.landmark', 'Near City Mall')            -- add / replace a JSON key
 WHERE JSON_UNQUOTE(JSON_EXTRACT(address, '$.city')) = 'Surat';

-- ---- DELETE with a subquery (trg_customers_ad writes the audit row) -------------------------
INSERT INTO customers (first_name, last_name, gender, email, phone, date_of_birth)
VALUES ('Temp', 'Person', 'O', 'temp.person@example.com', '9111122222', '1999-01-01');
DELETE FROM customers
 WHERE first_name = 'Temp'
   AND customer_id NOT IN (SELECT customer_id FROM accounts);

-- ---- A rejected statement (kept as a comment so the script can run end to end) ------------------
-- INSERT INTO customers (first_name,last_name,email,phone,date_of_birth)
-- VALUES ('Minor','Kid','kid@example.com','9222233333', CURDATE() - INTERVAL 10 YEAR);
-- ERROR 1644 (45000): Customer must be at least 18 years old

SELECT customer_id, full_name, email, kyc_status FROM customers ORDER BY customer_id;
