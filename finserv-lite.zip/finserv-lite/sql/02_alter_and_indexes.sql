-- =============================================================================
-- FinServ Lite - 02_alter_and_indexes.sql
-- Topic    : ALTER TABLE, CREATE/DROP INDEX, FULLTEXT, invisible index,
--            functional index, TRUNCATE, RENAME, temporary tables.
-- Run order: 2 of 14
-- =============================================================================
USE finserv_lite;

-- ---- ALTER TABLE: add, modify, rename, drop columns --------------------------
ALTER TABLE customers ADD COLUMN gender ENUM('M', 'F', 'O') NULL AFTER last_name;
ALTER TABLE branches  ADD COLUMN contact_no VARCHAR(15) NULL;
ALTER TABLE branches  MODIFY COLUMN contact_no VARCHAR(20) NULL COMMENT 'Landline or mobile';
ALTER TABLE branches  RENAME COLUMN contact_no TO phone_no;
ALTER TABLE branches  DROP COLUMN phone_no;

-- ---- ALTER TABLE: add a constraint after the table exists --------------------
ALTER TABLE customers
    ADD CONSTRAINT ck_customers_name CHECK (CHAR_LENGTH(TRIM(first_name)) > 0 AND CHAR_LENGTH(TRIM(last_name)) > 0);

-- ---- Indexes ------------------------------------------------------------------
CREATE INDEX idx_customers_name ON customers (last_name, first_name);        -- composite
CREATE INDEX idx_customers_kyc  ON customers (kyc_status);                   -- low-cardinality
CREATE FULLTEXT INDEX ft_customers_name ON customers (first_name, last_name);-- FULLTEXT search
CREATE INDEX idx_customers_email_domain ON customers ((SUBSTRING_INDEX(email, '@', -1))); -- functional index
CREATE INDEX idx_txn_type_date ON transactions (txn_type, txn_date);

-- Invisible index: the optimizer ignores it, so you can test dropping it safely.
CREATE INDEX idx_accounts_opened ON accounts (opened_on);
ALTER TABLE accounts ALTER INDEX idx_accounts_opened INVISIBLE;
ALTER TABLE accounts ALTER INDEX idx_accounts_opened VISIBLE;
DROP INDEX idx_accounts_opened ON accounts;                                  -- drop it again

-- ---- Rename table (and back) and TRUNCATE on a scratch table ----------------------
CREATE TABLE scratch_demo (id INT PRIMARY KEY AUTO_INCREMENT, note VARCHAR(20));
INSERT INTO scratch_demo (note) VALUES ('a'), ('b');
RENAME TABLE scratch_demo TO scratch_renamed;
TRUNCATE TABLE scratch_renamed;      -- removes all rows and resets AUTO_INCREMENT (DDL, cannot be rolled back)
DROP TABLE scratch_renamed;

-- ---- Temporary table: exists only for this connection ----------------------------
CREATE TEMPORARY TABLE tmp_demo (n INT);
INSERT INTO tmp_demo VALUES (1), (2), (3);
SELECT SUM(n) AS temp_total FROM tmp_demo;
DROP TEMPORARY TABLE tmp_demo;

-- ---- Check the result ----------------------------------------------------------------
SHOW INDEX FROM customers;
