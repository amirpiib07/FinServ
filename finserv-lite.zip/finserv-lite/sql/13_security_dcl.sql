-- =============================================================================
-- FinServ Lite - 13_security_dcl.sql
-- Topic    : DCL - CREATE USER, roles, GRANT / REVOKE (database, table, column
--            and routine level), SHOW GRANTS, password policy, resource limits.
-- Run order: 13 of 14   |   Run as an administrator (root).
-- Note     : Change the example passwords before any real use.
-- =============================================================================
USE finserv_lite;

DROP USER IF EXISTS 'bank_teller_user'@'localhost', 'bank_auditor_user'@'localhost', 'bank_admin_user'@'localhost';
DROP ROLE IF EXISTS 'bank_teller', 'bank_auditor', 'bank_admin';

-- Roles bundle privileges; users get roles.
CREATE ROLE 'bank_teller', 'bank_auditor', 'bank_admin';

-- Teller: read reporting views, run the money procedures, see only some customer columns.
GRANT SELECT ON finserv_lite.v_customer_accounts TO 'bank_teller';
GRANT SELECT ON finserv_lite.v_active_accounts   TO 'bank_teller';
GRANT SELECT (customer_id, full_name, kyc_status, phone) ON finserv_lite.customers TO 'bank_teller';   -- column level
GRANT EXECUTE ON PROCEDURE finserv_lite.sp_deposit        TO 'bank_teller';                           -- routine level
GRANT EXECUTE ON PROCEDURE finserv_lite.sp_withdraw       TO 'bank_teller';
GRANT EXECUTE ON PROCEDURE finserv_lite.sp_transfer       TO 'bank_teller';
GRANT EXECUTE ON PROCEDURE finserv_lite.sp_open_account   TO 'bank_teller';
GRANT EXECUTE ON PROCEDURE finserv_lite.sp_account_statement TO 'bank_teller';

-- Auditor: read-only on everything, including the audit trail.
GRANT SELECT ON finserv_lite.* TO 'bank_auditor';

-- Admin: everything inside this database, and may pass privileges on.
GRANT ALL PRIVILEGES ON finserv_lite.* TO 'bank_admin' WITH GRANT OPTION;

-- Users: password policy and resource limits.
CREATE USER 'bank_teller_user'@'localhost'  IDENTIFIED BY 'Teller#2026_Change'
    WITH MAX_QUERIES_PER_HOUR 5000 MAX_USER_CONNECTIONS 10
    PASSWORD EXPIRE INTERVAL 90 DAY
    FAILED_LOGIN_ATTEMPTS 5 PASSWORD_LOCK_TIME 1;
CREATE USER 'bank_auditor_user'@'localhost' IDENTIFIED BY 'Auditor#2026_Change';
CREATE USER 'bank_admin_user'@'localhost'   IDENTIFIED BY 'Admin#2026_Change';

GRANT 'bank_teller'  TO 'bank_teller_user'@'localhost';
GRANT 'bank_auditor' TO 'bank_auditor_user'@'localhost';
GRANT 'bank_admin'   TO 'bank_admin_user'@'localhost';
SET DEFAULT ROLE ALL TO 'bank_teller_user'@'localhost', 'bank_auditor_user'@'localhost', 'bank_admin_user'@'localhost';

-- REVOKE: take a privilege away again.
GRANT DELETE ON finserv_lite.branches TO 'bank_teller';
REVOKE DELETE ON finserv_lite.branches FROM 'bank_teller';

-- Inspect the result.
SHOW GRANTS FOR 'bank_teller';
SHOW GRANTS FOR 'bank_teller_user'@'localhost' USING 'bank_teller';
SHOW GRANTS FOR 'bank_auditor';
SELECT user, host, account_locked, password_expired FROM mysql.user WHERE user LIKE 'bank\_%';

-- Procedures run with SQL SECURITY DEFINER by default, so a teller who may only EXECUTE
-- sp_deposit still cannot read or update the accounts table directly.
