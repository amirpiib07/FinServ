-- =============================================================================
-- FinServ Lite - 09_seed_activity.sql
-- Topic    : Calling stored procedures (CALL with OUT variables) and
--            "time travel" with SET timestamp so the ledger has real history.
-- Run order: 9 of 14
-- How      : SET @@session.timestamp makes NOW(), CURDATE() and every
--            DEFAULT CURRENT_TIMESTAMP behave as if it were that moment.
--            It is reset at the end of the script.
-- =============================================================================
USE finserv_lite;

-- ============================ April 2026: accounts and loans =================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-06 10:00:00');
CALL sp_open_account( 1, 1, 1,  50000.00, @a1);    -- Aarav, Surat, Savings
CALL sp_open_account( 1, 2, 2, 100000.00, @a2);    -- Aarav, Mumbai, Current
CALL sp_open_account( 2, 1, 1, 120000.00, @a3);    -- Priya, Surat, Savings
CALL sp_open_account( 3, 2, 3,  30000.00, @a4);    -- Rohan, Mumbai, Salary
CALL sp_open_account( 4, 3, 1,  75000.00, @a5);    -- Ananya, Delhi, Savings
CALL sp_open_account( 5, 3, 2, 500000.00, @a6);    -- Vikram, Delhi, Current
CALL sp_open_account( 6, 1, 4,   5000.00, @a7);    -- Neha, Surat, Student
CALL sp_open_account( 7, 1, 1, 250000.00, @a8);    -- Karan, Surat, Savings
CALL sp_open_account( 8, 4, 3,  45000.00, @a9);    -- Sneha, Chennai, Salary
CALL sp_open_account(11, 2, 1,  15000.00, @a10);   -- Imran, Mumbai, Savings

SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-10 11:00:00');
CALL sp_apply_for_loan(1, @a1, 300000.00, 10.50,  36, @l1);   -- long personal loan
CALL sp_apply_for_loan(2, @a3, 150000.00,  9.00,  12, @l2);
CALL sp_apply_for_loan(4, @a5,  50000.00, 12.00,   4, @l3);   -- short loan, will be fully repaid
CALL sp_apply_for_loan(7, @a8, 800000.00,  8.75, 120, @l4);   -- stays APPLIED

SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-15 12:00:00');
CALL sp_approve_loan(@l1);
CALL sp_approve_loan(@l3);

SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary April');
CALL sp_deposit(@a9, 52000.00, 'Salary April');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-28 15:00:00');
CALL sp_transfer(@a2, @a1,  20000.00, 'Business reimbursement');
CALL sp_transfer(@a6, @a8, 100000.00, 'Property advance');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-04-30 23:00:00');
CALL sp_apply_interest('2026-04-30', @n);

-- ================================= May 2026 ==================================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-05-05 10:15:00');
CALL sp_withdraw(@a3, 15000.00, 'ATM withdrawal');
CALL sp_withdraw(@a1,  5000.00, 'Cash withdrawal');
CALL sp_deposit(@a10,  8000.00, 'Cash deposit');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-05-10 09:00:00');
CALL sp_pay_emi(@l1);
CALL sp_pay_emi(@l3);

SET @@session.timestamp = UNIX_TIMESTAMP('2026-05-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary May');
CALL sp_deposit(@a9, 52000.00, 'Salary May');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-05-31 23:00:00');
CALL sp_apply_interest('2026-05-31', @n);

-- ================================= June 2026 =================================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-06-03 10:00:00');
CALL sp_approve_loan(@l2);
CALL sp_transfer(@a3, @a5, 10000.00, 'Gift');
CALL sp_withdraw(@a8, 25000.00, 'Cash withdrawal');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-06-10 09:00:00');
CALL sp_pay_emi(@l1);
CALL sp_pay_emi(@l2);
CALL sp_pay_emi(@l3);

SET @@session.timestamp = UNIX_TIMESTAMP('2026-06-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary June');
CALL sp_deposit(@a9, 52000.00, 'Salary June');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-06-30 23:00:00');
CALL sp_apply_interest('2026-06-30', @n);

-- ================================= July 2026 =================================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-07-05 14:00:00');
CALL sp_deposit(@a7, 3000.00, 'Pocket money');
CALL sp_transfer(@a9, @a4, 5000.00, 'Rent share');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-07-10 09:00:00');
CALL sp_pay_emi(@l1);
CALL sp_pay_emi(@l2);
CALL sp_pay_emi(@l3);

SET @@session.timestamp = UNIX_TIMESTAMP('2026-07-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary July');
CALL sp_deposit(@a9, 52000.00, 'Salary July');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-07-31 23:00:00');
CALL sp_apply_interest('2026-07-31', @n);

-- ================================ August 2026 ================================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-08-04 11:00:00');
CALL sp_transfer(@a6, @a2, 75000.00, 'Working capital');
CALL sp_withdraw(@a5, 20000.00, 'Cash withdrawal');
CALL sp_deposit(@a8, 60000.00, 'Cheque deposit');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-08-10 09:00:00');
CALL sp_pay_emi(@l1);
CALL sp_pay_emi(@l2);
CALL sp_pay_emi(@l3);                                        -- 4th EMI: loan 3 becomes CLOSED

SET @@session.timestamp = UNIX_TIMESTAMP('2026-08-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary August');
CALL sp_deposit(@a9, 52000.00, 'Salary August');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-08-31 23:00:00');
CALL sp_apply_interest('2026-08-31', @n);

-- =============================== September 2026 ==============================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-09-02 10:30:00');
CALL sp_open_account(9, 1, 1, 10000.00, @a11);               -- Arjun, after KYC was verified

SET @@session.timestamp = UNIX_TIMESTAMP('2026-09-10 09:00:00');
CALL sp_pay_emi(@l1);
CALL sp_pay_emi(@l2);

SET @@session.timestamp = UNIX_TIMESTAMP('2026-09-20 09:30:00');
CALL sp_deposit(@a4, 45000.00, 'Salary September');
CALL sp_deposit(@a9, 52000.00, 'Salary September');
CALL sp_transfer(@a1, @a11, 2500.00, 'Welcome gift');

SET @@session.timestamp = UNIX_TIMESTAMP('2026-09-30 23:00:00');
CALL sp_apply_interest('2026-09-30', @n);

-- ================================= October 2026 ==============================
SET @@session.timestamp = UNIX_TIMESTAMP('2026-10-01 09:00:00');
UPDATE accounts SET status = 'FROZEN' WHERE account_no = @a10;   -- audited by trg_accounts_au

SET @@session.timestamp = DEFAULT;                               -- back to the real clock

SELECT 'accounts' AS item, COUNT(*) AS n FROM accounts
UNION ALL SELECT 'transactions', COUNT(*) FROM transactions
UNION ALL SELECT 'loans', COUNT(*) FROM loans
UNION ALL SELECT 'loan_payments', COUNT(*) FROM loan_payments
UNION ALL SELECT 'audit_log rows', COUNT(*) FROM audit_log;
