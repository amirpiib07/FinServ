-- =============================================================================
-- FinServ Lite - 03_functions.sql
-- Topic    : Stored functions (DETERMINISTIC / READS SQL DATA / NO SQL),
--            numeric, string, date, CASE and control-flow functions.
-- Run order: 3 of 14
-- Note     : Every function declares DETERMINISTIC, NO SQL or READS SQL DATA,
--            which MySQL requires when binary logging is enabled.
-- =============================================================================
USE finserv_lite;
DELIMITER $$

-- EMI = P * r * (1+r)^n / ((1+r)^n - 1), r = annual rate / 12 / 100
DROP FUNCTION IF EXISTS fn_calculate_emi$$
CREATE FUNCTION fn_calculate_emi(p_principal DECIMAL(12,2), p_annual_rate DECIMAL(5,2), p_months INT)
RETURNS DECIMAL(12,2)
DETERMINISTIC NO SQL
BEGIN
    DECLARE r DOUBLE DEFAULT p_annual_rate / 1200;
    IF p_months <= 0 THEN
        RETURN NULL;                                   -- invalid input
    ELSEIF r = 0 THEN
        RETURN ROUND(p_principal / p_months, 2);       -- interest-free loan
    END IF;
    RETURN ROUND(p_principal * r * POW(1 + r, p_months) / (POW(1 + r, p_months) - 1), 2);
END$$

-- Show only the last 4 digits: XXXXXXXX1234
DROP FUNCTION IF EXISTS fn_mask_account$$
CREATE FUNCTION fn_mask_account(p_account_no CHAR(12))
RETURNS VARCHAR(12)
DETERMINISTIC NO SQL
BEGIN
    RETURN CONCAT(REPEAT('X', CHAR_LENGTH(p_account_no) - 4), RIGHT(p_account_no, 4));
END$$

-- Random 12-digit account number starting with 5 (uniqueness is checked by the caller)
DROP FUNCTION IF EXISTS fn_generate_account_no$$
CREATE FUNCTION fn_generate_account_no()
RETURNS CHAR(12)
NOT DETERMINISTIC NO SQL
BEGIN
    RETURN CONCAT('5', LPAD(FLOOR(RAND() * 100000000000), 11, '0'));
END$$

-- Age in whole years at today's date
DROP FUNCTION IF EXISTS fn_age_years$$
CREATE FUNCTION fn_age_years(p_dob DATE)
RETURNS INT
NOT DETERMINISTIC NO SQL
BEGIN
    RETURN TIMESTAMPDIFF(YEAR, p_dob, CURDATE());
END$$

-- Days since the account was opened (reads a table, so READS SQL DATA)
DROP FUNCTION IF EXISTS fn_account_age_days$$
CREATE FUNCTION fn_account_age_days(p_account_id INT UNSIGNED)
RETURNS INT
NOT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_opened DATE;
    SELECT opened_on INTO v_opened FROM accounts WHERE account_id = p_account_id;
    RETURN DATEDIFF(CURDATE(), v_opened);
END$$

-- Sum of all open balances of a customer (0 when none)
DROP FUNCTION IF EXISTS fn_customer_total_balance$$
CREATE FUNCTION fn_customer_total_balance(p_customer_id INT UNSIGNED)
RETURNS DECIMAL(16,2)
NOT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(16,2);
    SELECT IFNULL(SUM(balance), 0) INTO v_total
    FROM accounts
    WHERE customer_id = p_customer_id AND status <> 'CLOSED';
    RETURN v_total;
END$$

-- Customer segment by total balance (CASE expression)
DROP FUNCTION IF EXISTS fn_customer_segment$$
CREATE FUNCTION fn_customer_segment(p_total DECIMAL(16,2))
RETURNS VARCHAR(10)
DETERMINISTIC NO SQL
BEGIN
    RETURN CASE
        WHEN p_total >= 1000000 THEN 'PLATINUM'
        WHEN p_total >= 250000  THEN 'GOLD'
        WHEN p_total >= 50000   THEN 'SILVER'
        ELSE 'BASIC'
    END;
END$$

DELIMITER ;

-- Quick self-test
SELECT fn_calculate_emi(500000, 9.5, 60) AS emi_500000_9_5_60,
       fn_mask_account('512345678901') AS masked,
       fn_customer_segment(300000)     AS segment;
