#!/usr/bin/env bash
# Runs every numbered script in order. Usage: ./run_all.sh [mysql options]
# Example: ./run_all.sh -u root -p
set -e
cd "$(dirname "$0")"
for f in [0-9][0-9]_*.sql; do
    echo ">>> $f"
    mysql "$@" --table < "$f"
done
echo "Done. Database finserv_lite is ready."
