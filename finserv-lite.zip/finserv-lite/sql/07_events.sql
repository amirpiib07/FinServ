-- =============================================================================
-- FinServ Lite - 07_events.sql
-- Topic    : MySQL Event Scheduler - recurring jobs inside the database.
-- Run order: 7 of 14
-- Note     : SET GLOBAL needs a privileged account (SUPER / SYSTEM_VARIABLES_ADMIN).
--            You can also put event_scheduler=ON in my.cnf.
-- =============================================================================
USE finserv_lite;
SET GLOBAL event_scheduler = ON;

DELIMITER $$

-- 1st of every month at 02:00: credit interest to every active interest-bearing account.
DROP EVENT IF EXISTS ev_monthly_interest$$
CREATE EVENT ev_monthly_interest
    ON SCHEDULE EVERY 1 MONTH
    STARTS (TIMESTAMP(DATE_FORMAT(CURRENT_DATE + INTERVAL 1 MONTH, '%Y-%m-01'), '02:00:00'))
    COMMENT 'Monthly interest posting'
DO
BEGIN
    CALL sp_apply_interest(CURDATE(), @interest_accounts);
END$$

-- Every day at 01:00: accounts with no activity for 365 days become DORMANT.
DROP EVENT IF EXISTS ev_mark_dormant$$
CREATE EVENT ev_mark_dormant
    ON SCHEDULE EVERY 1 DAY
    STARTS (TIMESTAMP(CURRENT_DATE + INTERVAL 1 DAY, '01:00:00'))
    COMMENT 'Flag inactive accounts'
DO
BEGIN
    UPDATE accounts
       SET status = 'DORMANT'
     WHERE status = 'ACTIVE'
       AND COALESCE(last_activity, opened_on) < NOW() - INTERVAL 365 DAY;
END$$

-- Every Sunday at 03:00: delete audit rows older than two years.
DROP EVENT IF EXISTS ev_purge_old_audit$$
CREATE EVENT ev_purge_old_audit
    ON SCHEDULE EVERY 1 WEEK
    STARTS (TIMESTAMP(CURRENT_DATE + INTERVAL (7 - WEEKDAY(CURRENT_DATE)) DAY, '03:00:00'))
    COMMENT 'Audit retention'
DO
    DELETE FROM audit_log WHERE changed_at < NOW() - INTERVAL 2 YEAR;
$$

DELIMITER ;

SELECT EVENT_NAME, STATUS, EVENT_TYPE, INTERVAL_VALUE, INTERVAL_FIELD, STARTS
FROM information_schema.EVENTS
WHERE EVENT_SCHEMA = 'finserv_lite';
