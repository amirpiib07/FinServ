-- =============================================================================
-- FinServ Lite - 04_views.sql
-- Topic    : Views - join view, aggregate view, view using functions,
--            updatable view WITH CHECK OPTION, view over a derived table.
-- Run order: 4 of 14
-- =============================================================================
USE finserv_lite;

-- Join of four tables; account numbers are masked with a stored function.
CREATE OR REPLACE VIEW v_customer_accounts AS
SELECT c.customer_id,
       c.full_name,
       a.account_id,
       fn_mask_account(a.account_no) AS masked_account,
       t.type_name,
       b.branch_name,
       a.balance,
       a.status
FROM customers     c
JOIN accounts      a ON a.customer_id = c.customer_id
JOIN account_types t ON t.type_id     = a.type_id
JOIN branches      b ON b.branch_id   = a.branch_id;

-- Aggregate view: one row per branch (LEFT JOIN keeps branches with no accounts).
CREATE OR REPLACE VIEW v_branch_summary AS
SELECT b.branch_id,
       b.branch_name,
       b.city,
       COUNT(a.account_id)              AS account_count,
       IFNULL(SUM(a.balance), 0)        AS total_balance,
       ROUND(IFNULL(AVG(a.balance), 0), 2) AS avg_balance,
       MAX(a.balance)                   AS max_balance
FROM branches b
LEFT JOIN accounts a ON a.branch_id = b.branch_id AND a.status <> 'CLOSED'
GROUP BY b.branch_id, b.branch_name, b.city;

-- Monthly money movement per transaction type.
CREATE OR REPLACE VIEW v_monthly_txn_summary AS
SELECT YEAR(txn_date)  AS txn_year,
       MONTH(txn_date) AS txn_month,
       txn_type,
       COUNT(*)        AS txn_count,
       SUM(amount)     AS total_amount
FROM transactions
GROUP BY YEAR(txn_date), MONTH(txn_date), txn_type;

-- Customer portfolio: uses two stored functions and a window function.
CREATE OR REPLACE VIEW v_customer_portfolio AS
SELECT customer_id,
       full_name,
       total_balance,
       fn_customer_segment(total_balance) AS segment,
       RANK() OVER (ORDER BY total_balance DESC) AS balance_rank
FROM (
    SELECT c.customer_id, c.full_name, fn_customer_total_balance(c.customer_id) AS total_balance
    FROM customers c
) AS x;

-- Updatable view: only ACTIVE accounts. WITH CHECK OPTION blocks rows that would leave the view.
CREATE OR REPLACE VIEW v_active_accounts AS
SELECT account_id, account_no, customer_id, branch_id, type_id, balance, status, opened_on
FROM accounts
WHERE status = 'ACTIVE'
WITH CHECK OPTION;

-- Loan status: derived table with SUM of payments; outstanding principal.
CREATE OR REPLACE VIEW v_loan_status AS
SELECT l.loan_id,
       l.customer_id,
       c.full_name,
       l.principal,
       l.annual_rate,
       l.months,
       l.emi,
       l.status,
       IFNULL(p.paid_principal, 0)           AS paid_principal,
       IFNULL(p.payments_made, 0)            AS payments_made,
       l.principal - IFNULL(p.paid_principal, 0) AS outstanding_principal
FROM loans l
JOIN customers c ON c.customer_id = l.customer_id
LEFT JOIN (
    SELECT loan_id, SUM(principal_part) AS paid_principal, COUNT(*) AS payments_made
    FROM loan_payments
    GROUP BY loan_id
) p ON p.loan_id = l.loan_id;

SELECT TABLE_NAME AS view_name, IS_UPDATABLE
FROM information_schema.VIEWS
WHERE TABLE_SCHEMA = 'finserv_lite'
ORDER BY TABLE_NAME;
